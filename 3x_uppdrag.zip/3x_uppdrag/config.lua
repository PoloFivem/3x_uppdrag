Config = {}

-- Allmänt
Config.PayoutMultiplier = 0.075 -- Desto högre lojalitet du har desto mer får du betalt om du gör lägre uppdrag, alltså 7.5% (0.075) för varje level uppdraget är under din lojalitet. (lojalitet - uppdrag) *  0,075
Config.SellMultiplier = 0.025 -- 2.5% per level
Config.Cooldown = math.random(1800, 3600) -- Cooldown för nya uppdrag
Config.SellWeapons = false

Config.EliasPos = vector3(-1165.2110595703, -1566.8408203125, 4.451470375061)
Config.EliasDeliveryPos = vector3(-1126.2458496094, -1566.9508056641, 4.3257460594177)
Config.RodriguezPos = vector3(2932.6298828125, 4284.3408203125, 71.958679199219)
Config.RodriguezDeliveryPos = vector3(2930.7568359375, 4309.2045898438, 50.777866363525)
Config.AntonPos = vector3(-583.43115234375, 5365.6962890625, 70.410766601563)
Config.AntonDeliveryPos = vector3(-566.07861328125, 5358.5092773438, 70.214401245117)
Config.PabloPos = vector3(149.25416564941, -1397.8774414063, 29.200138092041)
Config.DealerPeds = {
	{dealerPed = eliasPed, hash = 'ig_tylerdix_02', x = -1165.2110595703, y = -1566.8408203125, z = 4.451470375061, h = 310.0, menuName = 'eliasMenu'},
	{dealerPed = rodriguezPed, hash = 'a_m_y_latino_01', x = 2932.6298828125, y = 4284.3408203125, z = 71.958679199219, h = 166.0, menuName = 'rodriguezMenu'},
	{dealerPed = antonPed, hash = 'mp_m_avongoon', x = -583.43115234375, y = 5365.6962890625, z = 70.410766601563, h = 250.0, menuName = 'antonMenu'},
	{dealerPed = pabloPed, hash = 'g_m_m_armboss_01', x = 907.26623535156, y = -1692.0721435547, z = 43.1116065979, h = 175.0, menuName = 'pabloMenu'},
}

-- Uppdrag 1:
-- MÅSTE FIXA SÅ MAN FÅR KOORDINATER TILL ELIAS VID ALLA SCRIPTS FÖR MAN KOMMER ANNARS INTE KUNNA SE BLIPPEN I SLUTET YEYE
Config.BlipRadiusPos1 = vector3(26.248531341553, -1723.8256835938, 31.697412490845)
Config.Reward1 = 750
Config.PedPositions = {
    {x = 114.39604949951, y = -1950.8487548828, z = 20.717967987061, h = 22.0, hash = 'a_m_m_beach_01', hasSold = false, hasSpawnedPed = false, pedNumber = ped1, blipName = ped1Blip},
    {x = 125.95432281494, y = -1856.7276611328, z = 24.845582962036, h = 150.0, hash = 'a_m_y_downtown_01', hasSold = false, hasSpawnedPed = false, pedNumber = ped2, blipName = ped2Blip},
    {x = 246.43463134766, y = -1625.0771484375, z = 29.146873474121, h = 123.0, hash = 'a_m_m_soucent_03', hasSold = false, hasSpawnedPed = false, pedNumber = ped3, blipName = ped3Blip},
    {x = 93.019996643066, y = -1511.2984619141, z = 29.266241073608, h = 88.0, hash = 'a_m_y_soucent_02', hasSold = false, hasSpawnedPed = false, pedNumber = ped4, blipName = ped4Blip},
    {x = -38.796398162842, y = -1524.1510009766, z = 31.373649597168, h = 318.0, hash = 'a_m_m_paparazzi_01', hasSold = false, hasSpawnedPed = false, pedNumber = ped5, blipName = ped5Blip},
    {x = -160.50932312012, y = -1544.8983154297, z = 35.060649871826, h = 260.0, hash = 'a_m_m_eastsa_01', hasSold = false, hasSpawnedPed = false, pedNumber = ped6, blipName = ped6Blip},
    {x = -154.7844543457, y = -1727.7266845703, z = 30.105712890625, h = 260.0, hash = 'a_m_y_stbla_01', hasSold = false, hasSpawnedPed = false, pedNumber = ped7, blipName = ped7Blip},
    {x = -248.01872253418, y = -1945.9172363281, z = 29.946048736572, h = 304.0, hash = 'a_m_m_soucent_01', hasSold = false, hasSpawnedPed = false, pedNumber = ped8, blipName = ped8Blip},
    {x = 292.90197753906, y = -1991.2071533203, z = 20.836410522461, h = 90.0, hash = 'a_m_m_eastsa_02', hasSold = false, hasSpawnedPed = false, pedNumber = ped9, blipName = ped9Blip},
    {x = 355.33004760742, y = -1805.5977783203, z = 28.874338150024, h = 51.0, hash = 'a_m_m_og_boss_01', hasSold = false, hasSpawnedPed = false, pedNumber = ped10, blipName = ped10Blip},
}

-- Uppdrag 2:
Config.TargetPed2 = vector3(26.344778060913, -1410.0161132812, 29.334953308105-1)
Config.TargetPedHeading2 = 225.0
Config.TargetPedName2 = 'a_m_m_malibu_01'
Config.Vehicle2 = 'a6avant'
-- Config.Vehicle2 = 'a6avant'
Config.VehicleSpawn2 = vector3(53.844829559326, -1417.5948486328, 29.352222442627-1)
Config.VehicleHeading = 225.0
Config.Destination = vector3(1372.9409179688, -1523.7456054688, 56.931289672852-1) -- Var bilen ska köra, ska vara i närheten av var man ska parkera
Config.DestinationPark = vector3(1372.9409179688, -1523.7456054688, 56.931289672852-1) -- Var bilen ska stanna
Config.DestinationHeading = 340.0 -- Vilket håll fordonet ska parkera åt
Config.Timer2 = 300 -- Hur lång tid du har på dig att göra uppdraget innan det avbryts, tar cirka 200 sekunder om du är snabb.
Config.DisplayTimer2 = false -- Om du vill se timern eller inte
Config.Reward2 = 150 -- Hur mycket pengar man får, det blir alltså 200 * 15 upp till 200 * 20
Config.MarijuanaAmount = math.random(5, 10)

-- Uppdrag 3
Config.TargetVehicleHorde3 = {x = 965.44067382813, y = -190.25775146484, z = 73.208374023438, x2 = 966.6962890625, y2 = -191.11599731445, z2 = 73.208374023438, x3 = 968.42431640625, y3 = -192.04769897461, z3 = 73.208374023438}
-- Config.TargetVehicleHorde3 = {x = 2160.8247070313, y = 3032.5473632813, z = 45.3567237854, x2 = 2160.3483886719, y2 = 3031.0712890625, z2 = 45.365104675293, x3 = 2159.8410644531, y3 = 3029.7238769531, z3 = 45.372756958008} -- Dev
Config.SpawnSquadPosition = vector3(963.86602783203, -196.71109008789, 73.145545959473)
-- Config.SpawnSquadPosition = vector3(2159.8403320313, 3029.7241210938, 45.3727684021) -- Dev
Config.TargetVehicleModel = 'sanctus'
Config.TruckVehicleModel = 'mule2'
Config.TruckVehiclePos = vector3(1980.4501953125, 3037.0539550781, 47.056343078613)
Config.TruckVehicleHeading = 240.0
Config.TargetPedHeading3 = 330.0
Config.TargetPedSkin = 'g_m_y_lost_01'
Config.TargetPedSkin2 = 'g_m_y_lost_02'
Config.TargetPedSkin3 = 'g_m_y_lost_03'
Config.Destination3 = vector3(1990.1384277344, 3070.240234375, 47.00216293335)
Config.Destination3_2 = vector3(1991.232421875, 3047.5883789063, 47.215099334717)
Config.ReadNotePos = vector3(1984.3071289063, 3035.5749511719, 47.056343078613)
Config.Reward3 = 1250

-- Uppdrag 4: Elias
Config.LockpickPos4 = vector3(919.81195068359, -569.64166259766, 58.375133514404-1)
Config.LockpickHeading4 = 30.0
Config.FrontDoorPos4 = vector3(920.1, -568.9, 58.4)
Config.BackDoorPos4 = vector3(913.3, -554.5, 58)
Config.AnimPos4 = vector3(919.45159912109, -569.89697265625, 58.375259399414-1)
Config.AnimPosHeading4 = 27.0
Config.Reward4 = 1500
Config.SearchPositions4 = {
    {x = 918.88433837891, y = -565.20361328125, z = 61.698120117188, hasLooted = false, pickupMessage = 'Du plockade upp lite smycken'},
    {x = 912.37121582031, y = -562.19024658203, z = 61.697113037109, hasLooted = false, pickupMessage = 'Du plockade upp ett USB minne'},
    {x = 920.89282226563, y = -563.89324951172, z = 61.698032379150, hasLooted = false, pickupMessage = 'Du plockade upp lite marijuana'},
    {x = 919.16107177734, y = -567.75842285156, z = 58.373546600342, hasLooted = false, pickupMessage = 'Du plockade upp en telefon'},
    {x = 921.19757080078, y = -564.92425537109, z = 58.373542785645, hasLooted = false, pickupMessage = 'Du plockade upp en nyckel'},
}
Config.HomeOwners4 = {
    {x = 918.61401367188, y = -562.11846923828, z = 58.373790740967, h = 170.0, hasSpawned = false, hash = 'a_c_husky', chance = 75, pedName = 'a_c_husky'},
    {x = 909.78985595703, y = -557.75396728516, z = 61.6979637146, h = 300.0, hasSpawned = false, hash = 'a_c_chop', chance = 50, pedName = 'a_c_chop'},
    {x = 909.93078613281, y = -558.03070068359, z = 61.697834014893, h = 300.0, hasSpawned = false, hash = 'a_c_chop', chance = 35, pedName = 'a_c_chop'},
}

-- Uppdrag 5:
Config.TargetVehiclePos5 = vector3(458.82165527344, -1091.3292236328, 29.20269203186)
Config.TargetVehicleHeading5 = 90.0
Config.TargetVehicleModel5 = 'baller4'
Config.LockpickText5 = vector3(458.87017822266, -1092.6628417969, 29.202697753906)
Config.LockpickPos5 = vector3(458.88174438477, -1093.0004882813, 29.202682495117)
Config.LockpickHeading = 6.0
Config.Reward5 = 1500

-------------------------------------------------- Rodriguez --------------------------------------------------
-- Uppdrag 1:
Config.TargetVehiclePos1_2 = vector3(1961.2525634766, 3050.5991210938, 46.807506561279)
-- Config.TargetVehiclePos1_2 = vector3(2067.3879394531, 4684.75, 41.186939239502) -- Dev
Config.TruckVehicleModel1_2 = 'mule2'
Config.TruckVehicleHeading1_2 = 50.0
Config.Destination1_2 = vector3(1807.5303955078, 4592.6860351563, 37.216430664063)
Config.DeliverPosition1_2 = vector3(2930.2629394531, 4307.3833007813, 50.707401275635)
Config.DestinationHeading1_2 = 37.0
Config.CokeAmount1_2 = math.random(0, 1) -- Glöm inte fixa itemet på servern, lol
Config.CokeKey = 'card672'
Config.CokeKeyChance = 0.2
Config.Reward1_2 = 1500
Config.Accuracy1_2 = 85
Config.Armor1_2 = 100
Config.TargetPedSettings1_2_1 = {Hash = 'g_m_y_lost_02', x = 1991.6585693359, y = 3047.9213867188, z = 47.2151222229, h = 0.0}
-- Config.TargetPedSettings1_2 = {Hash = 'g_m_y_lost_02', x = 2063.7668457031, y = 4681.7290039063, z = 41.190010070801, h = 0.0} -- Dev
Config.TargetPedSettings1_2_2 = {Hash = 'g_m_y_lost_03', x = 1991.6585693359, y = 3047.9213867188, z = 47.2151222229, h = 0.0} -- 1_2_2 betyder 1: Rodriguez uppdrag nummer 1, 2: Eftersom det är Rodriguez stäter vi en tvåa så Elias första uppdrag inte fuckas, sista tvåan är för ped nummret
-- Config.TargetPedSettings1_2_3 = {Hash = 'g_m_y_lost_03', x = 2056.9841308594, y = 4678.640625, z = 41.247779846191, h = 0.0} -- Dev
Config.TargetPedSettings1_2_3 = {Hash = 'g_m_y_lost_01', x = 1804.6524658203, y = 4596.1674804688, z = 37.579471588135-1, h = 190.0}
Config.TargetPedSettings1_2_4 = {Hash = 'g_m_y_lost_01', x = 1809.6848144531, y = 4596.1489257813, z = 37.385341644287-1, h = 190.0}

-- Uppdrag 2:

Config.VehicleToDeliverSpawn2_2 = vector3(2930.2629394531, 4307.3833007813, 50.707401275635)
Config.VehicleToDeliverHeading2_2 = 294.0
Config.VehicleTunePos2_2 = vector3(480.43127441406, -1317.4819335938, 29.203113555908)
Config.VehicleTuneHeading2_2 = 118.0
Config.PickupCratesPos2_2 = vector3(178.91600036621, -1403.4674072266, 29.34369468689-1)
Config.VehicleToUpgrade2_2 = 'baller4'
Config.VehicleToDeliver2_2 = 'baller5'
Config.Reward2_2 = 1500

-- Uppdrag 7: (WIP)
-- Config.TargetPedPos3 = vector3(120.02865600586, -1077.1090087891, 29.192373275757)
Config.TargetPedPos7 = {
	{x = 167.61758422852, y = -1632.2872314453, z = 29.291660308838, x2 = 120.4533996582, y2 = -1697.3693847656, z2 = 29.111957550049},
	-- {x = 259.5637512207, y = -1634.7274169922, z = 29.6877593994140},
	-- {x = 350.58276367188, y = -1808.9387207031, z = 28.684083938599},
}
Config.PedVehicle7 = 'f620'
Config.VehicleHeading7 = 92.0
Config.BlipLocation7 = vector3(131.04125976563, -1684.2083740234, 29.243041992188)
Config.TargetPedHeading7 = 0.0
Config.TargetPedName7 = 'a_m_m_eastsa_02'

-- Specialerbjudande: (WIP)
Config.BlipCoordsSpecial = vector3(124.10065460205, -1047.5238037109, 29.192352294922-0.8)
Config.BlipCoordsSpecialRadius = 35.0
Config.ChangeBlip = vector3(124.10065460205, -1047.5238037109, 29.192352294922)

Config.Timer3 = 100 -- Borde egentligen inte behöva siffror på namnet då timern fungerar då du inte kan köra fler uppdrag på samma gång