ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

local sec = 0
local uppdrag1Timer = 0 -- E1
local uppdrag2Timer = 0 -- E2
local uppdrag3Timer = 0 -- E3
local uppdrag4Timer = 0 -- E4
local uppdrag5Timer = 0 -- E5
local uppdrag1_2Timer = 0 -- R1
local uppdrag2_2Timer = 0 -- R2
local uppdrag1_3Timer = 0 -- A1
local cashPayout = 0

-- RegisterServerEvent('zyke_uppdragRefreshMissionPed')
-- AddEventHandler('zyke_uppdragRefreshMissionPed', function()
--     spawnedPed = false
-- end)

-- Citizen.CreateThread(function()
--     while true do
--         Wait(10)
--         if not spawnedPed then
--             local MissionPedPos = Config.MissionPedPos[math.random(#Config.MissionPedPos)]
--             -- local MissionPedPos = Config.MissionPedPos
--             spawnedPed = true
--             TriggerClientEvent('zyke_uppdragMissionPed', -1, MissionPedPos)
--             -- TriggerEvent('esx:showNotification', 'Test, ignorera 3')
--             print('test 3')
--         end
--     end
-- end)

RegisterServerEvent('zyke-uppdragAddCooldown')
AddEventHandler('zyke-uppdragAddCooldown', function(currentDifficulty)
    if currentDifficulty == 1 then
        uppdrag1Timer = uppdrag1Timer + Config.Cooldown
    end
    if currentDifficulty == 2 then
        uppdrag2Timer = uppdrag2Timer + Config.Cooldown
    end
    if currentDifficulty == 3 then
        uppdrag3Timer = uppdrag3Timer + Config.Cooldown
    end
    if currentDifficulty == 4 then
        uppdrag4Timer = uppdrag4Timer + Config.Cooldown
    end
    if currentDifficulty == 5 then
        uppdrag5Timer = uppdrag5Timer + Config.Cooldown
    end
    if currentDifficulty == 51 then
        uppdrag1_2Timer = uppdrag1_2Timer + Config.Cooldown
    end
    if currentDifficulty == 52 then
        uppdrag2_2Timer = uppdrag2_2Timer + Config.Cooldown
    end
    Timer(currentDifficulty)
end)

function Timer(currentDifficulty)
    if currentDifficulty == 1 then
        while uppdrag1Timer > 0 do
            -- print('Uppdrag 1: ' .. uppdrag1Timer .. '')
            Wait(1000)
            uppdrag1Timer = uppdrag1Timer - 1
        end
    end
    if currentDifficulty == 2 then
        while uppdrag2Timer > 0 do
            -- print('Uppdrag 2: ' .. uppdrag2Timer .. '')
            Wait(1000)
            uppdrag2Timer = uppdrag2Timer - 1
        end
    end
    if currentDifficulty == 3 then
        while uppdrag3Timer > 0 do
            -- print('Uppdrag 3: ' .. uppdrag3Timer .. '')
            Wait(1000)
            uppdrag3Timer = uppdrag3Timer - 1
        end
    end
    if currentDifficulty == 4 then
        while uppdrag4Timer > 0 do
            -- print('Uppdrag 4: ' .. uppdrag4Timer .. '')
            Wait(1000)
            uppdrag4Timer = uppdrag4Timer - 1
        end
    end
    if currentDifficulty == 5 then
        while uppdrag5Timer > 0 do
            -- print('Uppdrag 5: ' .. uppdrag5Timer .. '')
            Wait(1000)
            uppdrag5Timer = uppdrag5Timer - 1
        end
    end
    if currentDifficulty == 51 then
        while uppdrag1_2Timer > 0 do
            -- print('Uppdrag 1_1: ' .. uppdrag1_2Timer .. '')
            Wait(1000)
            uppdrag1_2Timer = uppdrag1_2Timer - 1
        end
    end
    if currentDifficulty == 52 then
        while uppdrag2_2Timer > 0 do
            -- print('Uppdrag 2_1: ' .. uppdrag2_2Timer .. '')
            Wait(1000)
            uppdrag2_2Timer = uppdrag2_2Timer - 1
        end
    end
end

RegisterServerEvent('zyke_uppdragSetCurrentDifficulty')
AddEventHandler('zyke_uppdragSetCurrentDifficulty', function(currentDifficulty)
    setMissionTimer = currentDifficulty
end)

ESX.RegisterServerCallback('zyke-uppdragCheckCooldown', function(source, cb)
    if setMissionTimer == 1 then
        if uppdrag1Timer == 0 then
            cb(true)
        else
            cb(false)
        end
    end
    if setMissionTimer == 2 then
        if uppdrag2Timer == 0 then
            cb(true)
        else
            cb(false)
        end
    end
    if setMissionTimer == 3 then
        if uppdrag3Timer == 0 then
            cb(true)
        else
            cb(false)
        end
    end
    if setMissionTimer == 4 then
        if uppdrag4Timer == 0 then
            cb(true)
        else
            cb(false)
        end
    end
    if setMissionTimer == 5 then
        if uppdrag5Timer == 0 then
            cb(true)
        else
            cb(false)
        end
    end
    if setMissionTimer == 51 then
        if uppdrag1_2Timer == 0 then
            cb(true)
        else
            cb(false)
        end
    end
    if setMissionTimer == 52 then
        if uppdrag2_2Timer == 0 then
            cb(true)
        else
            cb(false)
        end
    end
end)

ESX.RegisterServerCallback('zyke_uppdragRetrieveSellItems', function(source, cb)
    local xPlayer = ESX.GetPlayerFromId(source)
    local item = xPlayer.getInventoryItem('ring1')
    local itemsToSell = {
        'ring1',
        'ring2'
    }
    for i = 1, #itemsToSell do
        if xPlayer.getInventoryItem(itemsToSell[i]).count > 0 then
            cb(true)
        else
            cb(false)
        end
    end
    -- if xPlayer.getInventoryItem('ring1').count > 0 then
    --     cb(true)
    -- else
    --     cb(false)
    -- end
end)

RegisterServerEvent('zyke_uppdragSellItems')
AddEventHandler('zyke_uppdragSellItems', function(level, item, price, name, names)
    local xPlayer = ESX.GetPlayerFromId(source)
    local hasItem = xPlayer.getInventoryItem(item)
    local quantity = hasItem.count
    payoutMultiplier = (level * Config.SellMultiplier + 1) - 0.025
    if payoutMultiplier > 1.25 then payoutMultiplier = 1.25 end
    local moneyAmount = price * payoutMultiplier
    -- print('test')

    if hasItem.count > 0 then
        xPlayer.addMoney(moneyAmount * quantity)
        xPlayer.removeInventoryItem(item, quantity)
        if quantity >= 2 then
            TriggerClientEvent('esx:showNotification', source, 'Du sålde ' .. quantity .. ' ' .. names .. ' och fick ' .. moneyAmount * quantity .. ' kr')
        else
            TriggerClientEvent('esx:showNotification', source, 'Du sålde ' .. quantity .. ' ' .. name .. ' och fick ' .. moneyAmount * quantity .. ' kr')
        end
    else
        TriggerClientEvent('esx:showNotification', source, 'Du har inga ' .. names .. '')
    end
end)

RegisterServerEvent('zyke_uppdragGiveReward')
AddEventHandler('zyke_uppdragGiveReward', function(level, cash, currentDifficulty, extraBonus, extraItems)
    local source = source
    xPlayer = ESX.GetPlayerFromId(source)
    payoutMultiplier = (level - currentDifficulty) * Config.PayoutMultiplier + 1
    cashPayout = cash
    if extraBonus then cashPayout = cashPayout * 1.1 end
    local moneyAmount = cashPayout * payoutMultiplier
    local bonusAmount = moneyAmount - cashPayout
    -- Fixa så det endast behövs en med typ if currentDifficulty == 1, och om din level är över den difficultyn så får du bonus etc

    if currentDifficulty == 1 then
        if level > 1 then
            TriggerClientEvent('esx:showNotification', source, 'Som belöning fick du, ~g~' .. cash .. ' ~s~kr')
            Wait(3000)
            TriggerClientEvent('esx:showNotification', source, 'På grund av din lojalitet fick du en liten bonus på din belöning, ~g~' .. bonusAmount .. ' ~s~kr')
            xPlayer.addMoney(moneyAmount)
        else
            local moneyAmount = cash
            xPlayer.addMoney(moneyAmount)
            TriggerClientEvent('esx:showNotification', source, 'Som tack fick du ~g~' .. moneyAmount .. ' ~s~kr')
        end
    end

    if currentDifficulty == 2 then
        if level > 2 then
            TriggerClientEvent('esx:showNotification', source, 'Som belöning fick du ~g~' .. cash .. ' ~s~kr')
            Wait(1500)
            TriggerClientEvent('esx:showNotification', source, 'På grund av din lojalitet fick du en liten bonus på din belöning, ~g~' .. bonusAmount .. ' ~s~kr')
            xPlayer.addMoney(cash + bonusAmount)
        else
            local moneyAmount = cash
            TriggerClientEvent('esx:showNotification', source, 'Som tack fick du ~g~' .. moneyAmount .. ' ~s~kr')
            xPlayer.addMoney(moneyAmount)
        end
    end

    if currentDifficulty == 3 then
        if level > 3 then
            TriggerClientEvent('esx:showNotification', source, 'Som belöning fick du ~g~' .. cash .. ' ~s~kr')
            Wait(1500)
            TriggerClientEvent('esx:showNotification', source, 'På grund av din lojalitet fick du en liten bonus på din belöning, ~g~' .. bonusAmount .. ' ~s~kr')
            xPlayer.addMoney(cash + bonusAmount)
        else
            local moneyAmount = cash
            TriggerClientEvent('esx:showNotification', source, 'Som tack fick du ~g~' .. moneyAmount .. ' ~s~kr')
            xPlayer.addMoney(moneyAmount)
        end
    end

    if currentDifficulty == 4 then
        if level > 4 then
            TriggerClientEvent('esx:showNotification', source, 'Som belöning fick du ~g~' .. cash .. ' ~s~kr')
            Wait(1500)
            TriggerClientEvent('esx:showNotification', source, 'På grund av din lojalitet fick du en liten bonus på din belöning, ~g~' .. bonusAmount .. ' ~s~kr')
            xPlayer.addMoney(cash + bonusAmount)
        else
            local moneyAmount = cash
            TriggerClientEvent('esx:showNotification', source, 'Som tack fick du ~g~' .. moneyAmount .. ' ~s~kr')
            xPlayer.addMoney(moneyAmount)
        end
    end

    if currentDifficulty == 5 then
        if level > 5 then
            TriggerClientEvent('esx:showNotification', source, 'Som belöning fick du ~g~' .. cash .. ' ~s~kr')
            Wait(1500)
            TriggerClientEvent('esx:showNotification', source, 'På grund av din lojalitet fick du en liten bonus på din belöning, ~g~' .. bonusAmount .. ' ~s~kr')
            xPlayer.addMoney(cash + bonusAmount)
        else
            local moneyAmount = cash
            TriggerClientEvent('esx:showNotification', source, 'Som tack fick du ~g~' .. moneyAmount .. ' ~s~kr')
            xPlayer.addMoney(moneyAmount)
        end
    end

    if currentDifficulty == 51 then
        if level > 1 then
            TriggerClientEvent('esx:showNotification', source, 'Som belöning fick du ~g~' .. cash .. ' ~s~kr')
            Wait(1500)
            TriggerClientEvent('esx:showNotification', source, 'På grund av din lojalitet fick du en liten bonus på din belöning, ~g~' .. bonusAmount .. ' ~s~kr')
            xPlayer.addMoney(cash + bonusAmount)
        else
            local moneyAmount = cash
            TriggerClientEvent('esx:showNotification', source, 'Som tack fick du ~g~' .. moneyAmount .. ' ~s~kr')
            xPlayer.addMoney(moneyAmount)
        end
    end

    if currentDifficulty == 52 then
        if level > 2 then
            TriggerClientEvent('esx:showNotification', source, 'Som belöning fick du ~g~' .. cash .. ' ~s~kr')
            Wait(1500)
            TriggerClientEvent('esx:showNotification', source, 'På grund av din lojalitet fick du en liten bonus på din belöning, ~g~' .. bonusAmount .. ' ~s~kr')
            xPlayer.addMoney(cash + bonusAmount)
        else
            local moneyAmount = cash
            TriggerClientEvent('esx:showNotification', source, 'Som tack fick du ~g~' .. moneyAmount .. ' ~s~kr')
            xPlayer.addMoney(moneyAmount)
        end
    end

    if extraItems then
        xPlayer.addInventoryItem('cokeingredients', Config.CokeAmount1_2)
    end

    if extraBonus then
        Wait(3000)
        TriggerClientEvent('esx:showNotification', source, 'Eftersom du löste det så snabbt fick du en liten bonus på din belöning, ~g~' .. cash * 0.1 .. ' ~s~kr')
        xPlayer.addMoney(cash * 0.1)
    end
end)

RegisterServerEvent('zyke_uppdragItemChance')
AddEventHandler('zyke_uppdragItemChance', function(mission)
    local xPlayer = ESX.GetPlayerFromId(source)

    if mission == 2 then
        local randomChance = math.random(0, 100)
        if randomChance >= 96 and randomChance <= 100 then -- 5% 3500 kr
            TriggerClientEvent('esx:showNotification', source, 'Du hittade en ring')
            xPlayer.addInventoryItem('ring2')
        end
        if randomChance >= 86 and randomChance <= 95 then -- 10% 2200 kr
            TriggerClientEvent('esx:showNotification', source, 'Du hittade en ring')
            xPlayer.addInventoryItem('ring1')
        end
    end
    if mission == 4 then
        local randomChance = math.random(0, 100)
        local randomAmount = math.random(20, 40)
        if randomChance >= 96 and randomChance <= 100 then -- 5%
            xPlayer.addInventoryItem('rifle_ammo', randomAmount)
            TriggerClientEvent('esx:showNotification', source, 'Du hittade lite ammunition')
        end
        if randomChance >= 55 and randomChance <= 56 then -- 2%
            TriggerClientEvent('esx:showNotification', source, 'Du hittade två nycklar')
            AddKey(xPlayer, {["keyName"] = 'Nyckel: Förråd #672', ["keyUnit"] = 'Förråd #672' }) -- sjrp_keysystem
        end
    end
end)

RegisterServerEvent('zyke_uppdragItemChanceTest')
AddEventHandler('zyke_uppdragItemChanceTest', function()
    local xPlayer = ESX.GetPlayerFromId(source)
    local randomChance = math.random(0, 1000) / 10

    if randomChance < Config.CokeKeyChance then
        xPlayer.addInventoryItem(Config.CokeKey, 1)
    end
    print(randomChance)

end)

-- RegisterCommand('addkeytest', function(source)
--     local xPlayer = ESX.GetPlayerFromId(source)
--     AddKey(xPlayer, {["keyName"] = 'Nyckel: Förråd #672', ["keyUnit"] = 'Förråd #672' }) -- sjrp_keysystem
-- end)

-- Från sjrp_keysystem
AddKey = function(player, newData)
    local keyData = {
        ["keyName"] = newData["keyName"] or "",
        ["keyUnit"] = newData["keyUnit"] or "",
        ["description"] = "Nyckel - " .. (newData["keyName"] or "") .. ".",
        ["label"] = newData["keyName"] or ""
    }

    if newData["type"] == "vehicle" then
        keyData["description"] = "Nyckel som tillhör ett fordon med plåten - " .. newData["keyName"]
    end

    player.addInventoryItem("key", 1, keyData)
end

-- Används inte
RegisterServerEvent('zyke_uppdragGiveReward2')
AddEventHandler('zyke_uppdragGiveReward2', function()
    xPlayer = ESX.GetPlayerFromId(source)
    local itemAmount = xPlayer.getInventoryItem('weed_poochuppdrag').count
    local moneyAmount = itemAmount * Config.Money
    xPlayer.addMoney(moneyAmount)
    xPlayer.removeInventoryItem('weed_poochuppdrag', itemAmount)
    TriggerClientEvent('esx:showNotification', source, 'Som belöning får du ' .. moneyAmount .. 'kr')
end)

-- Används inte
RegisterServerEvent('zyke_uppdragGiveItem')
AddEventHandler('zyke_uppdragGiveItem', function(itemAmount)
    xPlayer = ESX.GetPlayerFromId(source)
    xPlayer.addInventoryItem('weed_poochuppdrag', itemAmount)
end)

-- RegisterServerEvent('zyketestyeet')
-- AddEventHandler('zyketestyeet', function(currentPed)
    
-- end)

ESX.RegisterServerCallback('zyke_uppdragLevelElias', function(source, cb)
    local identifier = ESX.GetPlayerFromId(source).identifier
    MySQL.Async.fetchAll("SELECT eliaslevel FROM `characters` WHERE `identifier` = @identifier",
    {
        ['@identifier'] = identifier
    },
    function(result)
        if identifier ~= nil then
            cb(result[1].eliaslevel)
        else
            print('Något knasigt har skett.')
        end
    end)
end)

ESX.RegisterServerCallback('zyke_uppdragLevelRodriguez', function(source, cb)
    local identifier = ESX.GetPlayerFromId(source).identifier
    MySQL.Async.fetchAll("SELECT rodriguezlevel FROM `characters` WHERE `identifier` = @identifier",
    {
        ['@identifier'] = identifier
    },
    function(result)
        if identifier ~= nil then
            cb(result[1].rodriguezlevel)
        else
            print('Något knasigt har skett.')
        end
    end)
end)

ESX.RegisterServerCallback('zyke_uppdragLevelAnton', function(source, cb)
    local identifier = ESX.GetPlayerFromId(source).identifier
    MySQL.Async.fetchAll("SELECT antonlevel FROM `characters` WHERE `identifier` = @identifier",
    {
        ['@identifier'] = identifier
    },
    function(result)
        if identifier ~= nil then
            cb(result[1].antonlevel)
        else
            print('Något knasigt har skett.')
        end
    end)
end)

RegisterServerEvent('zyke_uppdragUpdateLevelElias')
AddEventHandler('zyke_uppdragUpdateLevelElias', function(newLevel)
    local identifier = ESX.GetPlayerFromId(source).identifier
    MySQL.Async.execute('UPDATE characters SET eliaslevel = @newLevel WHERE identifier = @identifier',
    {
        ['@identifier'] = identifier,
        ['@newLevel'] = newLevel
    },
    function (rowsChanged)
        -- print("Lojalitet uppdaterad från " ..identifier.. " nivå " ..newLevel)
    end)
end)

RegisterServerEvent('zyke_uppdragUpdateLevelRodriguez')
AddEventHandler('zyke_uppdragUpdateLevelRodriguez', function(newLevel)
    local identifier = ESX.GetPlayerFromId(source).identifier
    MySQL.Async.execute('UPDATE characters SET rodriguezlevel = @newLevel WHERE identifier = @identifier',
    {
        ['@identifier'] = identifier,
        ['@newLevel'] = newLevel
    },
    function (rowsChanged)
        -- print("Lojalitet uppdaterad från " ..identifier.. " nivå " ..newLevel)
    end)
end)

RegisterServerEvent('zyke_uppdragUpdateLevelAnton')
AddEventHandler('zyke_uppdragUpdateLevelAnton', function(newLevel)
    local identifier = ESX.GetPlayerFromId(source).identifier
    MySQL.Async.execute('UPDATE characters SET antonlevel = @newLevel WHERE identifier = @identifier',
    {
        ['@identifier'] = identifier,
        ['@newLevel'] = newLevel
    },
    function (rowsChanged)
        -- print("Lojalitet uppdaterad från " ..identifier.. " nivå " ..newLevel)
    end)
end)

RegisterServerEvent('zyke_uppdragPurchase')
AddEventHandler('zyke_uppdragPurchase', function(level, purchase, amount, price, finalDiscount, buyLabel, buyLabels)
    local xPlayer = ESX.GetPlayerFromId(source)
    local finalPrice = price - price * (finalDiscount * 0.01)

    if xPlayer.getMoney() >= finalPrice then
        xPlayer.addInventoryItem(purchase, amount)
        xPlayer.removeMoney(finalPrice)
        TriggerClientEvent('esx:showNotification', source, 'Du betalade: ' .. finalPrice .. '')
    else
        local slutcash = finalPrice - xPlayer.getMoney()
        TriggerClientEvent('esx:showNotification', source, 'Du är pank bre, du saknar ' .. slutcash .. ' kr.')
    end
end)

ESX.RegisterServerCallback('zyke_uppdragRetrieveItem', function(source, cb, item)
    local xPlayer = ESX.GetPlayerFromId(source)

    if xPlayer.getInventoryItem(item).count > 0 then
        cb(true)
    else
        cb(false)
    end
end)