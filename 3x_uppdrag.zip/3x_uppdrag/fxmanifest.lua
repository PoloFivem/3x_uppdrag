fx_version 'adamant'

game 'gta5'

client_scripts {
    -- '@es_extended/locale.lua',
    "client/*",
    "config.lua"
}

server_scripts {
    '@mysql-async/lib/MySQL.lua',
	-- '@es_extended/locale.lua',
    "server/*",
    "config.lua"
}

