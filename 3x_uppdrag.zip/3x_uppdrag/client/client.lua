ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

-- To do:
-- Animationer, snygga till markers, text osv.
-- Fler uppdrag, kanske upp till fem stycken.
-- Åker man in i fängelse förlorar man lojalitet.
-- Fixa fler positioner där bilen ska åka på uppdrag 2 så man inte alltid vet, samma med personen på uppdrag 1.
-- Är du polis kan du trycka E och hitta honom på olika ställen, då springer han iväg och just det stället är blacklistat från att han kan spawna. (Kanske)
-- På till exempel uppdrag två kan det finnas en gömd funktion där du kan söka genom personens bil, typ hitta en pistol i backluckan eller någonting, kanske chans att få en pistol om du söker genom honom osv.
-- Kanske fixa svårighetsgrader? Alltså accuracy, vapen, HP, armor, antal peds osv osv. Typ normal, svår och väldigt svår.
-- Snygga till scriptet och försök lägga uppdragen i olika filer.
-- Fixa så att det endast kan säljas typ ett vapen på 24h hos black market, kanske måste göra en callback för att förhindra att flertal köper vapnet samtidigt.
-- Kanske måste fixa så att bränsle osv sätts på en bra nivå till uppdrag 2 och framöver, men det borde inte vara något problem (Kanske)
-- Fixa så man behöver göra uppdrag 3 för att göra uppdrag 4 varje gång man loggar in och efter varje gång man gör uppdrag 4, kanske? Typ som heist, man gör olika setups för att sedan göra något stort

-- Specialerbjudanden:
-- Göra så att man kan få specialerbjudanden där du ska hämta saker. Det kan vara allt från ett borrmaskin till droger, gör man detta får man en ganska stor bonus. Det händer inte speciellt ofta och har man fått-
-- erbjudandet så får man inte det på ett tag, alltså cooldown i databasen.
-- Kanske händer varje timme att den väljer en random från servern som har gjort uppdrag hos Elias innan, högre lojalitet kanske ger högre chans?

-- Buggar:
-- Sätt
-- Man kan endast hamna i -1 lojalitet, antingen gör så man kan gå ner mer eller gör så man inte kan gå under 0-1. (Får tänka på att detta endast bör ge minus om man har högre lojalitet, alltså mer känd osv)
-- Fixa överallt:
-- SetEntityAsMissionEntity(targetPed, true, true)
-- NetworkRegisterEntityAsNetworked(targetPed)
-- Måste göra så att positionen väljs server-sida istället för client-sida för misisonped, möjligtvis alla peds för de har olika spawns för alla spelare
-- Körde uppdrag 2, sedan 1 och fick ingen marker efter jag hade dödat targetPed
-- Något uppdrag får du typ 0.24 kr, mest troligen pga procentuell
-- Pga NPC reducering scripts så fuckas NPC:erna och despawnar om man kommer för långt ifrån dem
-- Fixa failsafe som kollar om en ped bara har respawnat eller faktiskt är död så folk inte förlorar sin lojalitet, skriv bara att personen rymde och despawna fordonet osv
-- Dödar du i uppdrag 2 tidigt så avslutas inte uppdraget

-- Uppdrag ?:
-- Man ska plantera någonting på typ en bil, förmodligen en spårsändare, då ser någon det och man måste skjuta dem eller något.

-- Uppdrag ?: Hitta gömstället med hjälp av spårsändaren och plantera bomber, stjäla droger eller något liknande

-- Fixa vehicle_tracker med att man gör en TriggerServerEvent, sedan gör -1 istället för source, eller så man kollar om man är polis och då körs det eller någonting

-- Fixa levlarna, Rodriguez bygger på Elias och Anton bygger på Rodriguez så man kör alla i ordning

-- Fixa så man får produceringssaker i uppdrag r1 istället för färdigt kokain

-- FIXA ALLA REWARDS

local pedSpawned = false
local jobStarted = false
local killMessage = false
local jobCompleted = false
local targetSpawned = false
local forceStop = false
local canFlee = false
local returnMsg = false
local engaged = false
local blipSpawned = false
local loadedLevel = false
local carSpawned = false
local eliasBlip = false
local startedWalking = false
local alreadyDead = false
local backupVehicleBlipSpawned = false
local hasKilledTargetPed = false
local extraBonus = false
local hasSpawned_4 = false
local startedDriving = false

local canPressAgain = true
local missionSetup = true
local hasBackupSpawned = true
local pickupPhone = true
local findBikerAreaMessage = true
local followMessageUppdrag3 = true

local level = 0
local prevLevel = 0
local currentDifficulty = 0
local hasTalked = 0
local lootedAreas = 0
local lockpickPercentage = 0
local actualKeyToPress = 38 -- E för att börja dyrka upp
local displayKey = ''

-- Uppdrag E4
local homeOwnerCommands4 = {}

-- Uppdrag 7:
local pedCommands = {}
local pedCommandsUppdrag3 = {}
local pedCommandsUppdrag1_4 = {}
local givePedWeapons = {
    'WEAPON_BAT',
    'WEAPON_PISTOL',
    'WEAPON_COMBATPISTOL',
    'WEAPON_KNIFE',
}

local allowedWeapons = { -- https://wiki.gtanet.work/index.php?title=Weapons_Models
0,              -- Ett "super" slag med handen verkar ge detta ID, vet inte om det är samma med typ pistoler då det är avstängt på min server
-1569615261,    -- Hands
-1716189206,    -- Knife
1737195953,     -- Nightstick
1317494643,     -- Hammer
-1786099057,    -- Bat
-2067956739,    -- Crowbar
1141786504,     -- Goldclub
-102323637,     -- Bottle
-1834847097,    -- Dagger
-102973651,     -- Hatchet
-656458692,     -- Knuckles
-581044007,     -- Machete
-1951375401,    -- Flashlight
-538741184,     -- Switchblade
-1810795771,    -- Poolcue
419712736,      -- Wrench
-853065399,     -- Battle axe
}

-- Specialerbjudande
local randomItem = nil
local eliasBlip = nil

------------------------------------------------------------------------------

-- Alla peds yeye
Citizen.CreateThread(function()
    while true do
        Wait(1)
        local player = GetPlayerPed(-1)
        local pCoords = GetEntityCoords(player)

        for _,dealer in pairs(Config.DealerPeds) do
            if not DoesEntityExist(dealer.dealerPed) then
                RequestModel(dealer.hash) while not HasModelLoaded(dealer.hash) do Wait(10) end
                dealer.dealerPed = CreatePed(4, dealer.hash, dealer.x, dealer.y, dealer.z-1, dealer.h, false, true)
                SetEntityAsMissionEntity(dealer.dealerPed, true, true)
                SetBlockingOfNonTemporaryEvents(dealer.dealerPed, true)
                SetEntityInvincible(dealer.dealerPed, true)
                FreezeEntityPosition(dealer.dealerPed, true)
            end

            if GetDistanceBetweenCoords(pCoords, dealer.x, dealer.y, dealer.z, true) < 2 then
                if not jobStarted then
                    DrawText3Ds(dealer.x, dealer.y, dealer.z+1, '[~r~E~w~] Prata', 0.4)
                    if GetDistanceBetweenCoords(pCoords, dealer.x, dealer.y, dealer.z, true) < 1.2 then
                        DrawText3Ds(dealer.x, dealer.y, dealer.z+1, '[~g~E~w~] Prata', 0.4)
                        if IsControlJustPressed(1, 38) then
                            loadedLevel = false
                            if dealer.menuName == 'eliasMenu' then
                                ESX.TriggerServerCallback('zyke_uppdragLevelElias', function(result) level = result end)
                                TriggerEvent('zyke_uppdragLoadingText', source)
                                Wait(500)
                                loadedLevel = true
                                BrowseEliasJobs(level)
                            elseif dealer.menuName == 'rodriguezMenu' then
                                ESX.TriggerServerCallback('zyke_uppdragLevelElias', function(result) eLevel = result end)
                                ESX.TriggerServerCallback('zyke_uppdragLevelRodriguez', function(result) level = result end)
                                TriggerEvent('zyke_uppdragLoadingText', source)
                                Wait(500)
                                loadedLevel = true
                                BrowseRodriguezJobs(level, eLevel)
                            elseif dealer.menuName == 'pabloMenu' then
                                ESX.TriggerServerCallback('zyke_uppdragLevelAnton', function(result) level = result end)
                                MainMenuPablo(level)
                                -- Wait(500)
                                -- loadedLevel = true
                            elseif dealer.menuName == 'antonMenu' then
                                ESX.TriggerServerCallback('zyke_uppdragLevelAnton', function(result) level = result end)
                                ESX.TriggerServerCallback('zyke_uppdragLevelElias', function(result) eLevel = result end)
                                ESX.TriggerServerCallback('zyke_uppdragLevelRodriguez', function(result) rLevel = result end)
                                TriggerEvent('zyke_uppdragLoadingText', source)
                                Wait(500)
                                loadedLevel = true
                                BrowseAntonJobs(level, eLevel, rLevel)
                            end
                        end
                    end
                else
                    if missionDone then
                        DrawText3Ds(dealer.x, dealer.y, dealer.z+1, '[~g~E~w~] Få belöning', 0.4)
                    else
                        DrawText3Ds(dealer.x, dealer.y, dealer.z+1, 'Uppdrag pågående', 0.4)
                    end
                end
            end
        end
    end
end)

RegisterNetEvent('zyke_uppdragLoadingText')
AddEventHandler('zyke_uppdragLoadingText', function()
    exports["sjrp_progressbar"]:StartDelayedFunction({
        ["text"] = "Laddar lojalitet",
        ["delay"] = 500
    })
end)

function StartJob(currentDifficulty)
    ESX.UI.Menu.CloseAll()
    ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'weamenu',
    {
        title = 'Starta uppdrag?',
        align = 'center',
        elements = {
            {label = 'Ja', value = 'ja'},
            {label = 'Nej', value = 'nej'},
        }
    },
    function(data, menu)
        local action = data.current.value
        
        if action == 'ja' then
            CheckCooldown(currentDifficulty)
            menu.close()
            -- inMenu = false
        end
        if action == 'nej' then
            menu.close()
            -- menu.close()
            -- inMenu = false
        end
        
    end,
    function(data, menu)
        JobOptions()
    end)
end

function CheckCooldown(currentDifficulty)
    TriggerServerEvent('zyke_uppdragSetCurrentDifficulty', currentDifficulty)
    ESX.TriggerServerCallback('zyke-uppdragCheckCooldown', function(cooldownDone)
        if cooldownDone then
            jobStarted = true
            jobCompleted = false
            DeletePed(targetPed)
            Wait(100)
            justAccepted = true
            TriggerServerEvent('zyke-uppdragAddCooldown', currentDifficulty)
            if currentDifficulty == 1 then
                TriggerEvent('zyke_uppdragMainEvent1', source, missionPedCoords)
                TriggerEvent('zyke_uppdragUppdrag1Dialogue', source)
            elseif currentDifficulty == 2 then
                TriggerEvent('zyke_uppdragMainEvent2', source, missionPedCoords)
                TriggerEvent('zyke_uppdragUppdrag2Dialogue', source)
            elseif currentDifficulty == 3 then
                TriggerEvent('zyke_uppdragMainEvent3', source, missionPedCoords)
                TriggerEvent('zyke_uppdragUppdrag3Dialogue', source)
            elseif currentDifficulty == 4 then
                TriggerEvent('zyke_uppdragMainEvent4', source, missionPedCoords)
                TriggerEvent('zyke_uppdragUppdrag4Dialogue', source)
            elseif currentDifficulty == 5 then
                TriggerEvent('zyke_uppdragMainEvent5', source, missionPedCoords)
                TriggerEvent('zyke_uppdragUppdrag5Dialogue', source)
            elseif currentDifficulty == 7 then
                TriggerEvent('zyke_uppdragMainEvent7', source, missionPedCoords)
                TriggerEvent('zyke_uppdragUppdrag7Dialogue', source)
            elseif currentDifficulty == 51 then
                TriggerEvent('zyke_uppdragMainEvent1_4', source, missionPedCoords)
                TriggerEvent('zyke_uppdragUppdrag1_4Dialogue', source)
            elseif currentDifficulty == 52 then
                TriggerEvent('zyke_uppdragMainEvent2_2', source, missionPedCoords)
                TriggerEvent('zyke_uppdragUppdrag2_2Dialogue', source)
            end
        else
            ESX.ShowNotification('Det finns inga jobb')
        end
    end)
end

-- Uppdrag 1
RegisterNetEvent('zyke_uppdragUppdrag1Dialogue')
AddEventHandler('zyke_uppdragUppdrag1Dialogue', function()
    while not jobCompleted do
        Wait(1)

        if justAccepted then
            justAccepted = false
            ESX.ShowNotification('Tjena, jag har lite affärer jag måste ta hand om')
            Wait(2000)
            ESX.ShowNotification('Ta dessa produkter och sälj till några kunder vid Grove Street')
            Wait(3000)
            ESX.ShowNotification('Kom tillbaka med pengarna och du får en andel')
        end
        
    end
end)

-- Kolla om man får bonus pga lojalitet
-- Uppdrag 1
RegisterNetEvent('zyke_uppdragMainEvent1')
AddEventHandler('zyke_uppdragMainEvent1', function()
    forceStop = false
    while not jobCompleted do
        Wait(1)

        local player = GetPlayerPed(-1)
        local pCoords = GetEntityCoords(player)
        local targetPedCoords = GetEntityCoords(ped1)
        local dist1 = #(pCoords - Config.EliasPos)

        if not DoesBlipExist(blipRadius1) and hasTalked < 10 then
            blipRadius1 = AddBlipForRadius(Config.BlipRadiusPos1, 400.0)
            SetBlipAlpha(blipRadius1, 100)
            SetBlipColour(blipRadius1, 46)
        end
        
        for _,p in pairs(Config.PedPositions) do
            local dist3 = GetDistanceBetweenCoords(pCoords, p.x, p.y, p.z, true)
            if dist3 < 75 and not p.hasSpawnedPed then
                p.hasSpawnedPed = true
                RequestModel(p.hash) while not HasModelLoaded(p.hash) do Wait(10) end
                p.pedNumber = CreatePed(4, p.hash, p.x, p.y, p.z-1, p.h, false, true)
                SetBlockingOfNonTemporaryEvents(p.pedNumber, true)
                SetBlockingOfNonTemporaryEvents(p.pedNumber, true)
                SetEntityAsMissionEntity(p.pedNumber, true, true)
            end
        end

        for _,p in pairs(Config.PedPositions) do
            pedCoords = GetEntityCoords(p.pedNumber)
            if GetDistanceBetweenCoords(pCoords, pedCoords.x, pedCoords.y, pedCoords.z, true) < 3 and not p.hasSold then
                DrawText3Ds(pedCoords.x, pedCoords.y, pedCoords.z+1, '[~g~E~w~] Prata', 0.4)
                if GetDistanceBetweenCoords(pCoords, pedCoords.x, pedCoords.y, pedCoords.z, true) < 2 and not p.hasSold then
                    if IsControlJustPressed(1, 38) then
                        local ped, pedDst = ESX.Game.GetClosestPed(pCoords)
                        if DoesEntityExist(ped) and pedDst < 3 then
                            p.pedNumber = RemoveBlip(p.blipName)
                            local pedPos = GetEntityCoords(ped)
                            if GetDistanceBetweenCoords(pCoords, pedPos, true) < 3 then
                                exports["sjrp_progressbar"]:StartDelayedFunction({
                                    ["text"] = 'Prata med kunden',
                                    ["delay"] = 2000
                                })
                                Wait(2000)
                                SetPedAsNoLongerNeeded(ped)
                                p.hasSold = true
                                hasTalked = hasTalked + 1
                            end
                        end
                    end
                end
            end
        end

        for _,p in pairs(Config.PedPositions) do
            if DoesEntityExist(p.pedNumber) then
                if not DoesBlipExist(p.blipName) then
                    p.blipName = AddBlipForEntity(p.pedNumber)
                    BlipDetails(p.blipName, 'Kund', 46, true)
                end
            end
        end

        if DoesBlipExist(blipRadius1) then
            DrawMissionText('Kunder avklarade: ' .. hasTalked .. '/10', 0.0, 0.5)
        end

        if hasTalked == 10 then
            DrawMissionText('Återvänd till Elias', 0.96, 0.5)
            if not DoesBlipExist(eliasBlip1) then
                eliasBlip1 = AddBlipForCoord(Config.EliasPos)
                BlipDetails(eliasBlip1, 'Elias', 46, true)
            end
            RemoveBlip(blipRadius1)
            missionDone = true
        end

        if dist1 < 3 then
            if IsControlJustPressed(1, 38) then
                TriggerServerEvent('zyke_uppdragGiveReward', level, Config.Reward1, 1, extraBonus) -- Fixa timer osv
                ESX.TriggerServerCallback('zyke_uppdragLevel', function(result) level = result end)
                if level < 2 then
                    TriggerServerEvent('zyke_uppdragUpdateLevelElias', 2)
                    ESX.ShowNotification('Du kan nu acceptera nya uppdrag')
                end
                forceStop = true
            end
        end

        if forceStop then
            jobCompleted = true
            jobStarted = false
            hasTalked = 0
            forceStop = false
            missionDone = false
            RemoveBlip(blipRadius1)
            RemoveBlip(eliasBlip1)
            for _,p in pairs(Config.PedPositions) do
                p.pedNumber = RemoveBlip(p.blipName)
                p.hasSold = false
                p.hasSpawnedPed = false
            end
        end
    end
end)


-- Uppdrag 2
RegisterNetEvent('zyke_uppdragUppdrag2Dialogue')
AddEventHandler('zyke_uppdragUppdrag2Dialogue', function()
    while not jobCompleted do
        Wait(1)

        if justAccepted then
            justAccepted = false
            ESX.ShowNotification('Skönt att du är tillbaka, behöver hjälp med lite affärer.')
            Wait(2000)
            ESX.ShowNotification('Ett mongo hasslade mina grabbar på lite grönt, du vet vad du ska göra.')
            Wait(3000)
            ESX.ShowNotification('Jag har hört att han kör ett svart fordon')
            Wait(2000)
            ESX.ShowNotification('Kör efter honom och ta hand om det på ett gömt ställe.')
        end
        
    end
end)

RegisterNetEvent('zyke_uppdragMainEvent2')
AddEventHandler('zyke_uppdragMainEvent2', function()
    forceStop = false
    while not jobCompleted do
        Wait(1)

        local player = GetPlayerPed(-1)
        local pHealth = GetEntityHealth(player)
        local pCoords = GetEntityCoords(player)
        local targetCoords = GetEntityCoords(targetPed)
        local targetPedHash = GetHashKey(Config.TargetPedName2)
        local vCoords = GetEntityCoords(vehicle1)
        local dist1 = #(pCoords - targetCoords)
        local dist2 = #(targetCoords - Config.Destination)
        local dist3 = #(pCoords - Config.EliasPos)
        local dist4 = #(targetCoords - Config.DestinationPark)
        local dist5 = #(pCoords - Config.TargetPed2)
        local dist6 = #(vCoords - Config.DestinationPark)
        local dist7 = #(pCoords - Config.VehicleSpawn2)
        local dict = 'anim@heists@prison_heistunfinished_biztarget_idle'
        local anim = 'target_idle'
        -- local vehicleName = Config.PedVehicle5
        local vehicleName = Config.Vehicle2
        RequestAnimDict("amb@medic@standing@kneel@exit")
        RequestAnimDict("anim@gangops@facility@servers@bodysearch@")
        RequestAnimDict("amb@medic@standing@kneel@base")
        while not HasAnimDictLoaded("amb@medic@standing@kneel@exit") do Wait(5) end
        while not HasAnimDictLoaded("anim@gangops@facility@servers@bodysearch@") do Wait(5) end
        while not HasAnimDictLoaded("amb@medic@standing@kneel@base") do Wait(5) end
        -- Används inte
        if not randomizedAlready then
            local itemAmount = Config.MarijuanaAmount
            itemAmount2 = itemAmount
            randomizedAlready = true
            -- print(itemAmount)
        end

        if not timerStarted then
            cancelTimer = false
            timerStarted = true
            timer = Config.Timer2
            TriggerEvent('zyke_uppdragTimer')
        end

        local targetHealth = GetEntityHealth(targetPed)
        local targetCoords = GetEntityCoords(targetPed)

        if not blipSpawned then
            blip = AddBlipForCoord(Config.TargetPed2)
            -- SetBlipSprite(blip, 1)
            SetBlipRoute(blip, true)
            blipSpawned = true
        end

        if dist1 < 20 then
            if not isPedInVehicle then
                if IsPedInAnyVehicle(targetPed) then
                    isPedInVehicle = true
                    followMessage = true
                    TaskVehicleDriveToCoordLongrange(targetPed, vehicle1, Config.Destination, 20.0, 6, 5)
                    -- 387 (Chill, men den hade problem med fordon vid sidan av vägen)
                    -- 2883621 (Ignorerar rödljus, typ)
                    -- 6 (Ignorerar allting och bara kör, typ)
                end
            end
        end

        if dist5 < 100 then
            if not carSpawned then
                RequestModel(vehicleName)
                while not HasModelLoaded(vehicleName) do Wait(10) end
                vehicle1 = CreateVehicle(GetHashKey(vehicleName), Config.VehicleSpawn2.x, Config.VehicleSpawn2.y, Config.VehicleSpawn2.z, Config.VehicleHeading, true, true)
                SetVehicleColours(vehicle1, 12, 12)
                SetVehicleWindowTint(vehicle1, 'WINDOWTINT_PURE_BLACK')
                SetModelAsNoLongerNeeded(vehicleName)
                carSpawned = true
            end

            if dist5 < 40 then
                if targetSpawned == false then
                    RequestModel(targetPedHash)
                    RequestAnimDict(dict)
                    while not HasModelLoaded(targetPedHash) do Wait(5) end
                    targetPed = CreatePed(4, targetPedHash, Config.TargetPed2, Config.TargetPedHeading2, false, true)
                    SetEntityAsMissionEntity(targetPed, true, true)
                    NetworkRegisterEntityAsNetworked(targetPed)
                    -- TaskWarpPedIntoVehicle(targetPed, vehicle1, -1)
                    targetSpawned = true
                end
                if dist5 < 35 then
                    if not startedWalking then
                        -- TaskWarpPedIntoVehicle(targetPed, vehicle1, -1)
                        TaskEnterVehicle(targetPed, vehicle1, -1, -1, 1.0, 1, 0)
                        startedWalking = true
                        RemoveBlip(blip)
                    end
                end
            end
        end

        if dist2 < 5 then
            arrivedAtDestination = true
        end

        if followMessage then
            if arrivedAtDestination then
                if targetHealth < 1 then
                    if not isSearched then
                        DrawMissionText('Sök genom individen', 0.96, 0.5)
                        if dist1 >= 1 and dist1 <= 2 then
                            DrawText3Ds(targetCoords.x, targetCoords.y, targetCoords.z, '~r~[E] ~w~Sök genom', 0.4)
                        end
                        if dist1 < 1.5 then
                            DrawText3Ds(targetCoords.x, targetCoords.y, targetCoords.z, '~g~[E] ~w~Sök genom', 0.4)
                            if not IsPedInAnyVehicle(player) then
                                if IsControlJustPressed(1, 38) then
                                    TaskPlayAnim(GetPlayerPed(-1), "amb@medic@standing@kneel@base" ,"base" ,8.0, -8.0, -1, 1, 0, false, false, false )
                                    Wait(100)
                                    TaskPlayAnim(GetPlayerPed(-1), "anim@gangops@facility@servers@bodysearch@" ,"player_search" ,8.0, -8.0, -1, 48, 0, false, false, false )
                                    Wait(5250)
                                    ESX.ShowNotification('Du sökte genom honom och fick ' .. itemAmount2 .. 'g grönt')
                                    TriggerServerEvent('zyke_uppdragItemChance', 2)
                                    Wait(1750)
                                    TaskPlayAnim(GetPlayerPed(-1), "amb@medic@standing@kneel@exit" ,"exit" ,8.0, -8.0, -1, 0, 0, false, false, false )
                                    -- TriggerServerEvent('zyke_uppdragGiveItem', itemAmount)
                                    isSearched = true
                                end
                            end
                        end
                    else
                        if not eliasBlip then
                            blip = AddBlipForCoord(Config.EliasPos)
                            SetBlipRoute(blip, true)
                            eliasBlip = true
                        end
                        DrawMissionText('Åk tillbaka till Elias och lämna över produkterna', 0.96, 0.5)
                    end
                else
                    DrawMissionText('Mörda individen med rätt beskrivning', 0.96, 0.5)
                    canKill = true
                end
            else
                DrawMissionText('Följ efter bilen med korrekt beskrivning', 0.96, 0.5)
            end
        end

        if targetHealth < 1 then
            if not canKill then
                if followMessage then
                    forceStop = true
                    killEarlyUppdrag1 = true
                    CancelMission('elias')
                end
            end
        end

        if pickupPhone then
            if dist4 < 20 then
                if not tasksCleared then
                    tasksCleared = true
                    ClearPedTasks(targetPed)
                    TaskVehiclePark(targetPed, vehicle1, Config.DestinationPark, Config.DestinationHeading, 1, 40.0, false)
                end
                if dist4 < 4 then
                    TaskLeaveVehicle(targetPed, vehicle1, 1)
                    SetVehicleDoorsLockedForAllPlayers(vehicle1, true)
                    if pickupPhone then
                        Wait(2500)
                        TaskStartScenarioInPlace(targetPed, 'world_human_stand_mobile', 0, true)
                        pickupPhone = false
                    end
                end
            end
        end 

        if isSearched then
            missionDone = true
            if dist3 < 1.5 then
                if IsControlJustPressed(1, 38) then
                    if timer > Config.Timer2 / 3 then
                        extraBonus = true
                    else
                        extraBonus = false
                    end
                    RemoveBlip(blip)
                    jobDone = true
                end
            end
        end

        if pHealth < 1 then
            RemoveBlip(blip)
            forceStop = true
        end

        if jobDone then
            TriggerServerEvent('zyke_uppdragGiveReward', level, itemAmount2 * Config.Reward2, 2, extraBonus)
            ESX.TriggerServerCallback('zyke_uppdragLevel', function(result) level = result end)
            if level < 3 then
                TriggerServerEvent('zyke_uppdragUpdateLevelElias', 3)
                ESX.ShowNotification('Du kan nu acceptera nya uppdrag')
            end
            jobDone = false
            forceStop = true
        end

        if forceStop then
            followMessage = false
            arrivedAtDestination = false
            isSearched = false
            activateMarker = false
            timerActivated = false
            carSpawned = false
            targetSpawned = false
            jobStarted = false
            pickupPhone = false
            missionDone = false
            tasksCleared = false
            canKill = false
            killEarlyUppdrag1 = false
            tookTooLong = false
            timerStarted = false
            cancelTimer = true
            jobCompleted = true
            forceStop = false
            startedWalking = false
            isPedInVehicle = false
            blipSpawned = false
            timer = 0
            RemoveBlip(blip)
            -- ResetMissionPed()
            DeleteVehicle(vehicle1)
        end
    end
end)

-- Citizen.CreateThread(function()
--     while true do
--         Wait(5)
--         local player = GetPlayerPed(-1)
--         local pCoords = GetEntityCoords(player)
--         local targetPed1Coords = GetEntityCoords(mainTargetPed)
--         local targetPed2Coords = GetEntityCoords(targetPed)
--         local targetPed3Coords = GetEntityCoords(targetPed2)
--         local dist1 = #(pCoords - targetPed1Coords)

--         if dist1 < 10 then
--             DrawText3Ds(targetPed1Coords.x, targetPed1Coords.y, targetPed1Coords.z+1, '1', 0.4)
--             DrawText3Ds(targetPed2Coords.x, targetPed2Coords.y, targetPed2Coords.z+1, '2', 0.4)
--             DrawText3Ds(targetPed3Coords.x, targetPed3Coords.y, targetPed3Coords.z+1, '3', 0.4)
--         end
--     end
-- end)

RegisterNetEvent('zyke_uppdragUppdrag3Dialogue')
AddEventHandler('zyke_uppdragUppdrag3Dialogue', function()
    while not jobCompleted do
        Wait(1)
        if justAccepted then
            justAccepted = false
            ESX.ShowNotification('Det finns ett nytt gäng i staden jag vill att du ska reda på information om')
            Wait(2000)
            ESX.ShowNotification('Jag har sett dem runt taxifirman mycket, se om du kan få reda på något mer')
        end
    end
end)

RegisterNetEvent('zyke_uppdragMainEvent3')
AddEventHandler('zyke_uppdragMainEvent3', function()
    forceStop = false
    while not jobCompleted do
        Wait(1)

        local player = GetPlayerPed(-1)
        local pCoords = GetEntityCoords(player)
        local mainTargetPedCoords = GetEntityCoords(mainTargetPed)
        local targePedCoords = GetEntityCoords(targetPed)
        local targePed2Coords = GetEntityCoords(targetPed2)
        local TargetVehicleHorde3 = Config.TargetVehicleHorde3
        local truckSpawn = Config.TruckVehiclePos
        local dist1 = #(pCoords - Config.SpawnSquadPosition)
        local dist2 = #(mainTargetPedCoords - Config.Destination3)
        local dist3 = #(targePedCoords - Config.Destination3)
        local dist4 = #(targePed2Coords - Config.Destination3)
        local dist5 = #(mainTargetPedCoords - Config.Destination3_2)
        local dist6 = #(pCoords - Config.Destination3)
        local dist7 = #(pCoords - Config.TruckVehiclePos)
        local dist8 = #(pCoords - Config.ReadNotePos)
        local dist9 = #(pCoords - Config.EliasPos)
        local dist10 = #(mainTargetPedCoords - Config.SpawnSquadPosition)

        if dist1 > 40 and not DoesBlipExist(bikerSearchArea) and findBikerAreaMessage then
            DrawMissionText('Åk till positionen markerad på din GPS och hitta motorcyklisterna', 0.96, 0.5)
        else
            if dist5 > 5 then
                DrawMissionText('Hitta motorcyklisterna och följ efter dem diskret', 0.96, 0.5)
                findBikerAreaMessage = false
            end
        end

        if missionSetup then
            findBikerBlip = AddBlipForCoord(Config.SpawnSquadPosition)
            SetBlipRoute(findBikerBlip, true)
            missionSetup = false
        end
        
        if followMessageUppdrag3 then
            if dist1 < 150 then
                if not DoesBlipExist(bikerSearchArea) then
                    bikerSearchArea = AddBlipForRadius(Config.SpawnSquadPosition, 150.0)
                    SetBlipColour(bikerSearchArea, 46)
                    SetBlipAlpha(bikerSearchArea, 100)
                    RemoveBlip(findBikerBlip)
                end
            end
        end

        if dist10 > 150 and hasDriven and DoesBlipExist(bikerSearchArea) then
            RemoveBlip(bikerSearchArea)
        end

        if dist1 < 50 then -- Spammas konstant när man kör om man är mer än 30 ifrån, typ
            -- ESX.ShowNotification('test 1') -- Debug
            if not DoesEntityExist(mainTargetPed) then
                RequestModel(Config.TargetVehicleModel) while not HasModelLoaded(Config.TargetVehicleModel) do Wait(10) end
                RequestModel(Config.TargetPedSkin) while not HasModelLoaded(Config.TargetPedSkin) do Wait(10) end
                RequestModel(Config.TargetPedSkin2) while not HasModelLoaded(Config.TargetPedSkin2) do Wait(10) end
                RequestModel(Config.TargetPedSkin3) while not HasModelLoaded(Config.TargetPedSkin3) do Wait(10) end
                AddRelationshipGroup('LostMC')
                vehicle1 = CreateVehicle(Config.TargetVehicleModel, TargetVehicleHorde3.x, TargetVehicleHorde3.y, TargetVehicleHorde3.z, Config.TargetVehicleHeading, true, true)
                vehicle2 = CreateVehicle(Config.TargetVehicleModel, TargetVehicleHorde3.x2, TargetVehicleHorde3.y2, TargetVehicleHorde3.z2, Config.TargetVehicleHeading, true, true)
                vehicle3 = CreateVehicle(Config.TargetVehicleModel, TargetVehicleHorde3.x3, TargetVehicleHorde3.y3, TargetVehicleHorde3.z3, Config.TargetVehicleHeading, true, true)
                mainTargetPed = CreatePed(4, Config.TargetPedSkin, TargetVehicleHorde3.x, TargetVehicleHorde3.y, TargetVehicleHorde3.z, Config.TargetPedHeading3, false, true) table.insert(pedCommandsUppdrag3, mainTargetPed)
                targetPed = CreatePed(4, Config.TargetPedSkin2, TargetVehicleHorde3.x2, TargetVehicleHorde3.y2, TargetVehicleHorde3.z2, Config.TargetPedHeading3, false, true) table.insert(pedCommandsUppdrag3, targetPed)
                targetPed2 = CreatePed(4, Config.TargetPedSkin3, TargetVehicleHorde3.x3, TargetVehicleHorde3.y3, TargetVehicleHorde3.z3, Config.TargetPedHeading3, false, true) table.insert(pedCommandsUppdrag3, targetPed2)
                TaskWarpPedIntoVehicle(mainTargetPed, vehicle1, -1)
                TaskWarpPedIntoVehicle(targetPed, vehicle2, -1)
                TaskWarpPedIntoVehicle(targetPed2, vehicle3, -1)
                Wait(10)
                for _,peds in pairs(pedCommandsUppdrag3) do
                    SetPedRelationshipGroupHash(peds, GetHashKey("LostMC"))
                    SetPedRelationshipGroupHash(player, GetHashKey("Player"))
                    SetRelationshipBetweenGroups(0, GetHashKey("LostMC"), GetHashKey("LostMC"))
                    NetworkRegisterEntityAsNetworked(peds)
                    -- SetRelationshipBetweenGroups(5, GetHashKey("LostMC"), GetHashKey("Player"))
                    -- SetRelationshipBetweenGroups(5, GetHashKey("Player"), GetHashKey("LostMC"))
                end
            end
        end

        if dist1 < 40 and not hasDriven then
            hasDriven = true
            TaskVehicleDriveToCoordLongrange(mainTargetPed, vehicle1, Config.Destination3, 20.0, 6, 5)
            TaskVehicleDriveToCoordLongrange(targetPed, vehicle2, Config.Destination3, 20.0, 6, 5)
            TaskVehicleDriveToCoordLongrange(targetPed2, vehicle3, Config.Destination3, 20.0, 6, 5)
        end

        if not StartedWalkingmainTargetPed then
            if dist2 < 10 and not mainTargetParked then
                TaskVehiclePark(mainTargetPed, vehicle1, Config.Destination3, 0.0, 0, 20.0, false)
                mainTargetParked = true
            else
                if dist2 < 3 then
                    TaskLeaveVehicle(mainTargetPed, vehicle1, 1)
                    spawnTruck = true
                    -- Wait(250)
                    TaskGoToCoordAnyMeans(mainTargetPed, Config.Destination3_2, 1.0, false)
                    StartedWalkingmainTargetPed = true
                end
            end
        end
        if not StartedWalkingtargetPed then
            if dist3 < 10 and not targetPedParked then
                TaskVehiclePark(targetPed, vehicle1, Config.Destination3, 0.0, 0, 20.0, false)
                targetPedParked = true
            else
                if dist3 < 3 then
                    TaskLeaveVehicle(targetPed, vehicle2, 1)
                    -- Wait(250)
                    TaskGoToCoordAnyMeans(targetPed, Config.Destination3_2, 1.0, false)
                    StartedWalkingtargetPed = true
                end
            end
        end
        if not StartedWalkingtargetPed2 then
            if dist4 < 10 and not targetPed2Parked then
                TaskVehiclePark(targetPed2, vehicle1, Config.Destination3, 0.0, 0, 20.0, false)
                targetPed2Parked = true
            else
                if dist4 < 3 then
                    TaskLeaveVehicle(targetPed2, vehicle3, 1)
                    -- Wait(250)
                    TaskGoToCoordAnyMeans(targetPed2, Config.Destination3_2, 1.0, false)
                    StartedWalkingtargetPed2 = true
                end
            end
        end
        if spawnTruck then
            RequestModel(Config.TruckVehicleModel)
            while not HasModelLoaded(Config.TruckVehicleModel) do Wait(10) end
            missionTruck3 = CreateVehicle(Config.TruckVehicleModel, truckSpawn.x, truckSpawn.y, truckSpawn.z, Config.TruckVehicleHeading, true, true)
            SetVehicleDoorsLockedForAllPlayers(missionTruck3, true)
            spawnTruck = false
        end
        if not returnMessage then
            if dist5 < 5 then
                if dist7 < 50 then
                    if not collectInfo then
                        DrawMissionText('Sök genom området', 0.96, 0.5)
                        followMessageUppdrag3 = false
                    end
                    if dist7 < 10 then
                        if not returnMessage then
                            DrawMissionText('Leta efter information', 0.96, 0.5)
                            collectInfo = true
                        end
                    else
                        collectInfo = false
                    end
                    if dist8 < 1.5 then
                        DrawText3Ds(Config.ReadNotePos.x, Config.ReadNotePos.y, Config.ReadNotePos.z, '[~g~E~w~]', 0.4)
                        if IsControlJustPressed(1, 38) then
                            returnMessage = true
                        end
                    end
                end
            end
        end
        if returnMessage then
            if not DoesBlipExist(returnToElias) then
                returnToElias = AddBlipForCoord(Config.EliasPos)
                SetBlipRoute(returnToElias, true)
            end
            if dist9 > 4 then
                DrawMissionText('Åk tillbaka till Elias med informationen', 0.96, 0.5)
            else
                DrawMissionText('Prata med Elias', 0.96, 0.5)
            end
        end
        
        if dist9 < 4 and returnMessage then
            missionDone = true
            if IsControlJustPressed(1, 38) then
                jobDone = true
            end
        end

        if jobDone then
            ESX.ShowNotification('Tack för informationen, jag återkommer snart')
            TriggerServerEvent('zyke_uppdragGiveReward', level, Config.Reward3, 3, extraBonus) -- Fixa timer osv
            ESX.TriggerServerCallback('zyke_uppdragLevel', function(result) level = result end)
            if level < 4 then
                TriggerServerEvent('zyke_uppdragUpdateLevelElias', 4)
                ESX.ShowNotification('Du kan nu acceptera nya uppdrag')
            end
            forceStop = true
            jobDone = false
        end

        -- if dist1 < 30 and dist10 > 100 then -- Tappade bort dem
        --     if not returnMessage then
        --         forceStop = true
        --     end
        -- end
        -- Failsafe om man inte är typ inom 100 och MC grabbarna redan är där, typ

        if forceStop then
            jobCompleted = true
            missionDone = false
            returnMessage = false
            collectInfo = false
            spawnTruck = false
            forceStop = false
            jobStarted = false
            missionSetup = true
            findBikerAreaMessage = true
            followMessageUppdrag3 = true
            RemoveBlip(findBikerBlip)
            RemoveBlip(bikerSearchArea)
            RemoveBlip(returnToElias)
            DeleteVehicle(missionTruck3)

            -- Resetta ped skiten
            StartedWalkingmainTargetPed = false
            StartedWalkingtargetPed = false
            StartedWalkingtargetPed2 = false
            mainTargetParked = false
            targetPedParked = false
            targetPed2Parked = false
            hasDriven = false
            DeleteVehicle(vehicle1)
            DeleteVehicle(vehicle2)
            DeleteVehicle(vehicle3)
            DeletePed(mainTargetPed)
            DeletePed(targetPed)
            DeletePed(targetPed2)
            -- SetModelAsNoLongerNeeded() -- Fixa detta så det tar mindre prestanda osv
        end
    end
end)

-- Elias uppdrag 4 Dialouge:
RegisterNetEvent('zyke_uppdragUppdrag4Dialogue')
AddEventHandler('zyke_uppdragUppdrag4Dialogue', function()
    while not jobCompleted do
        Wait(1)
        if justAccepted then
            justAccepted = false
            ESX.ShowNotification('Såg på Instagram att ett par shunos var utomlands')
            Wait(3000)
            ESX.ShowNotification('Åk till adressen och checka om det finns något att ta')
        end
    end
end)

-- Elias Uppdrag 4:
-- Fixa så typ en hund spawnar som attackerar eller någonting liknande
RegisterNetEvent('zyke_uppdragMainEvent4')
AddEventHandler('zyke_uppdragMainEvent4', function()
    forceStop = false
    while not jobCompleted do
        Wait(1)

        local player = GetPlayerPed(-1)
        local pCoords = GetEntityCoords(player)
        local dist1 = #(pCoords - Config.LockpickPos4)
        local dist2 = #(pCoords - Config.EliasPos)
        local frontDoor = GetClosestObjectOfType(Config.FrontDoorPos4, 1.0, GetHashKey('v_ilev_fa_frontdoor'), false, false, false)
        local backDoor = GetClosestObjectOfType(Config.BackDoorPos4, 1.0, GetHashKey('v_ilev_bk_door2'), false, false, false)

        if dist1 > 5 and not hasLockpicked then
            if not DoesBlipExist(destinationBlip) then
                destinationBlip = AddBlipForCoord(Config.LockpickPos4)
                BlipDetails(destinationBlip, 'Hus', 46, true)
            end
            DrawMissionText('Åk till positionen markerad på din GPS', 0.96, 0.5)
        end

        if dist1 < 5 and not hasLockpicked then
            DrawMarker(25, Config.LockpickPos4, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 255, 0, 0, 100, false, true, 2, false, false, false, false)
            DrawMissionText('Bryt dig in i huset', 0.96, 0.5)
            if dist1 < 1.5 and not hasLockpicked then
                DrawMarker(25, Config.LockpickPos4, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 0, 255, 0, 100, false, true, 2, false, false, false, false)
                if IsControlJustPressed(1, 38) then
                    ESX.TriggerServerCallback('zyke_uppdragRetrieveItem', function(hasItem)
                        if hasItem then
                            FreezeEntityPosition(player, true)
                            SetEntityHeading(player, Config.AnimPosHeading4)
                            SetEntityCoords(player, Config.AnimPos4)
                            ESX.LoadAnimDict("mini@safe_cracking")
                            TaskPlayAnim(player, 'mini@safe_cracking', 'idle_base', 1.0, -1.0, 15000, 69, 0, 0, 0, 0)
                            exports["sjrp_progressbar"]:StartDelayedFunction({
                                ["text"] = "Låser upp dörren",
                                ["delay"] = 15000
                            })
                            Wait(15000)
                            RemoveBlip(destinationBlip)
                            hasLockpicked = true
                            FreezeEntityPosition(frontDoor, false)
                            FreezeEntityPosition(player, false)
                            for _,homeowners in pairs(Config.HomeOwners4) do
                                chance = math.random(0, 100)
                                if chance < homeowners.chance then
                                    AddRelationshipGroup('HomeOwners')
                                    RequestModel(homeowners.hash) while not HasModelLoaded(homeowners.hash) do Wait(10) end
                                    homeowners.pedName = CreatePed(4, homeowners.hash, homeowners.x, homeowners.y, homeowners.z-1, homeowners.h, false, true) table.insert(homeOwnerCommands4, homeowners.pedName)
                                    for k,peds in pairs(homeOwnerCommands4) do
                                        print(peds)
                                        ESX.ShowNotification('Spawned:' .. peds .. '')
                                        SetPedCombatAttributes(peds, 46, 1)
                                        SetPedCombatAbility(peds, 100)
                                        SetPedCombatMovement(peds, 3)
                                        SetPedSeeingRange(peds, 100000000.0)
                                        SetPedHearingRange(peds, 100000000.0)
                                        SetPedRelationshipGroupHash(peds, GetHashKey("HomeOwners"))
                                        SetPedRelationshipGroupHash(player, GetHashKey("Player"))
                                        SetRelationshipBetweenGroups(0, GetHashKey("HomeOwners"), GetHashKey("HomeOwners"))
                                        SetRelationshipBetweenGroups(5, GetHashKey("HomeOwners"), GetHashKey("Player"))
                                        SetRelationshipBetweenGroups(5, GetHashKey("Player"), GetHashKey("HomeOwners"))
                                    end
                                end
                            end
                        else
                            ESX.ShowNotification('Köp ett dyrkset först')
                        end
                    end, 'lockpick')
                end
            end
        end

        -- Looting system
        if hasLockpicked then
            for _,loot in pairs(Config.SearchPositions4) do
                if GetDistanceBetweenCoords(pCoords, loot.x, loot.y, loot.z, true) < 1.5 and not loot.hasLooted then
                    DrawText3Ds(loot.x, loot.y, loot.z, '[~r~E~w~]', 0.4)
                    if GetDistanceBetweenCoords(pCoords, loot.x, loot.y, loot.z, true) < 0.5 then
                        DrawText3Ds(loot.x, loot.y, loot.z, '[~g~E~w~]', 0.4)
                        if IsControlJustPressed(1, 38) then
                            exports["sjrp_progressbar"]:StartDelayedFunction({
                                ["text"] = "Söker genom",
                                ["delay"] = 5000
                            })
                            TaskStartScenarioInPlace(PlayerPedId(), "PROP_HUMAN_BUM_BIN", 0, true)
                            Wait(5000)
                            ClearPedTasks(GetPlayerPed(-1))
                            ESX.ShowNotification(loot.pickupMessage)
                            lootedAreas = lootedAreas + 1
                            loot.hasLooted = true
                        end
                    end
                end
            end
        end

        if lootedAreas < 5 and hasLockpicked then
            DrawMissionText('Sök genom huset efter föremålen Elias söker', 0.96, 0.5)
        elseif lootedAreas == 5 then
            missionDone = true
        end

        if missionDone then
            DrawMissionText('Åk tillbaka till Elias och lämna över föremålen', 0.96, 0.5)
            if not DoesBlipExist(eliasBlip) then
                eliasBlip = AddBlipForCoord(Config.EliasPos)
                BlipDetails(eliasBlip, 'Elias', 46, true)
            end
            if dist2 < 2 and IsControlJustPressed(1, 38) then
                forceStop = true
                ESX.ShowNotification('Tack för grejerna, jag återkommer mer fler saker du kan hämta åt mig')
                TriggerServerEvent('zyke_uppdragGiveReward', level, Config.Reward4, 4, extraBonus) -- Fixa timer osv
                ESX.TriggerServerCallback('zyke_uppdragLevelElias', function(result) level = result end)
                if level < 5 then
                    TriggerServerEvent('zyke_uppdragUpdateLevelElias', 5)
                    ESX.ShowNotification('Du kan nu acceptera nya uppdrag')
                end
            end
        end
                

        if dist1 < 10 and not hasLockpicked then
            FreezeEntityPosition(frontDoor, true)
            FreezeEntityPosition(backDoor, true)
        end

        if forceStop then
            forceStop = false
            jobStarted = false
            missionDone = false
            hasLockpicked = false
            jobCompleted = true
            missionSetup = true
            lootedAreas = 0
            RemoveBlip(eliasBlip)
            RemoveBlip(destinationBlip)
            FreezeEntityPosition(frontDoor, false)
            FreezeEntityPosition(backDoor, false)
            for _,loot in pairs(Config.SearchPositions4) do
                loot.hasLooted = false
            end
        end
    end
end)

local randomKeys = {
    268, -- S
    266, -- D
    44, -- Q
    38, -- E
}

-- Elias Uppdrag 5: Bilstöld
-- Fixa så man måste köpa dyrkset innan, fixa så det finns flertal bilar så du tar den med korrekt beskrivning
-- Sno baller4, omfärgad till svart, hos Rodriguez ska du göra affärer med några så du får en baller5, sedan hos Anton ska du använda bilen till något, även fixa skottsäkra däck om det går, kanske även åka och hämta en leverans med vapen till Rodriguez som sedan används hos Anton
-- Kanske gör så man ligger på span så kör bilen in till parkeringen
RegisterNetEvent('zyke_uppdragMainEvent5')
AddEventHandler('zyke_uppdragMainEvent5', function()
    forceStop = false
    while not jobCompleted do
        Wait(1)

        local player = GetPlayerPed(-1)
        local pCoords = GetEntityCoords(player)
        local dist1 = #(pCoords - Config.TargetVehiclePos5)
        local dist2 = #(pCoords - Config.EliasDeliveryPos)
        local dist3 = #(pCoords - Config.EliasPos)

        if dist1 > 10 and not hasLockpicked then
            if not DoesBlipExist(findVehicleArea5) then
                findVehicleArea5 = AddBlipForCoord(Config.TargetVehiclePos5)
                BlipDetails(findVehicleArea5, 'Fordon', 46, true)
            end
            DrawMissionText('Leta reda på fordonet Elias söker', 0.96, 0.5)
        else
            if not hasLockpicked then
                DrawMissionText('Bryt upp fordonet', 0.96, 0.5)
            end
        end

        if dist1 < 75 then
            if not DoesEntityExist(targetVehicle5) and not hasLockpicked then
                RequestModel(Config.TargetVehicleModel5) while not HasModelLoaded(Config.TargetVehicleModel5) do Wait(10) end
                targetVehicle5 = CreateVehicle(Config.TargetVehicleModel5, Config.TargetVehiclePos5, Config.TargetVehicleHeading5, true, true)
                SetVehicleDoorsLockedForAllPlayers(targetVehicle5, true)
                SetVehicleColours(targetVehicle5, 12, 12)
                SetVehicleWindowTint(targetVehicle5, 'WINDOWTINT_PURE_BLACK')
                SetVehicleNumberPlateText(targetVehicle5, 'yeye')
                SetVehicleDirtLevel(targetVehicle5, 0.0)
            end
        end


        if dist1 < 5 and not hasLockpicked then
            if currentlyLockpicking then
                if actualKeyToPress == 268 then
                    displayKey = 'S'
                elseif actualKeyToPress == 266 then
                    displayKey = 'D'
                elseif actualKeyToPress == 44 then
                    displayKey = 'Q'
                elseif actualKeyToPress == 38 then
                    displayKey = 'E'
                end
                keyToPress = randomKeys[math.random(1, #randomKeys)]
                if hasAttemptedLockpicking then
                    if lockpickPercentage >= 0 and lockpickPercentage <= 500 then
                        DrawText3Ds(Config.LockpickText5.x, Config.LockpickText5.y, Config.LockpickText5.z, '[' .. displayKey .. '] ~r~' .. lockpickPercentage / 10 .. '%\n~s~[~r~X~s~] För att avbryta', 0.45)
                    elseif lockpickPercentage >= 501 and lockpickPercentage <= 750 then
                        DrawText3Ds(Config.LockpickText5.x, Config.LockpickText5.y, Config.LockpickText5.z, '[' .. displayKey .. '] ~o~' .. lockpickPercentage / 10 .. '%\n~s~[~r~X~s~] För att avbryta', 0.45)
                    elseif lockpickPercentage >= 751 and lockpickPercentage <= 1000 then
                        DrawText3Ds(Config.LockpickText5.x, Config.LockpickText5.y, Config.LockpickText5.z, '[' .. displayKey .. '] ~g~' .. lockpickPercentage / 10 .. '%\n~s~[~r~X~s~] För att avbryta', 0.45)
                    end
                end
                if dist1 < 2 then
                    if canPressAgain then
                        if IsControlJustPressed(1, actualKeyToPress) then
                            ESX.LoadAnimDict('anim@amb@clubhouse@tutorial@bkr_tut_ig3@')
                            SetEntityCoords(player, Config.LockpickPos5.x, Config.LockpickPos5.y, Config.LockpickPos5.z-1)
                            SetEntityHeading(player, Config.LockpickHeading)
                            TaskPlayAnim(player, 'anim@amb@clubhouse@tutorial@bkr_tut_ig3@', 'machinic_loop_mechandplayer', 3.0, 1.0, -1, 31, 0, 0, 0)
                            actualKeyToPress = keyToPress
                            ESX.TriggerServerCallback('zyke_uppdragRetrieveItem', function(hasItem)
                                if hasItem then
                                    lockpickPercentage = lockpickPercentage + math.random(0, 50)
                                    canPressAgain = false
                                    TriggerEvent('zyke_uppdragMainEvent5Timer', source)
                                    if lockpickPercentage >= 1000 then
                                        hasLockpicked = true
                                        SetVehicleDoorsLockedForAllPlayers(targetVehicle5, false)
                                        FreezeEntityPosition(player, false)
                                        RemoveBlip(findVehicleArea5)
                                        ClearPedTasks(player)
                                        ClearPedSecondaryTask(player)
                                    end
                                else
                                    ESX.ShowNotification('Du har inget dyrkset')
                                end
                            end, 'lockpick')
                        end
                    end
                end
                if IsControlJustPressed(1, 73) then -- X
                    ESX.ShowNotification('Du avbröt')
                    currentlyLockpicking = false
                    FreezeEntityPosition(player, false)
                end
            else
                if hasAttemptedLockpicking then
                    if lockpickPercentage >= 0 and lockpickPercentage <= 500 then
                        DrawText3Ds(Config.LockpickText5.x, Config.LockpickText5.y, Config.LockpickText5.z, '[E] ~r~' .. lockpickPercentage / 10 .. '%', 0.45)
                    elseif lockpickPercentage >= 501 and lockpickPercentage <= 750 then
                        DrawText3Ds(Config.LockpickText5.x, Config.LockpickText5.y, Config.LockpickText5.z, '[E] ~o~' .. lockpickPercentage / 10 .. '%', 0.45)
                    elseif lockpickPercentage >= 751 and lockpickPercentage <= 1000 then
                        DrawText3Ds(Config.LockpickText5.x, Config.LockpickText5.y, Config.LockpickText5.z, '[E] ~g~' .. lockpickPercentage / 10 .. '%', 0.45)
                    end
                end
                if IsControlJustPressed(1, 38) then
                    currentlyLockpicking = true
                    hasAttemptedLockpicking = true
                    FreezeEntityPosition(player, true)
                end
            end
        end

        if hasLockpicked and not missionDone then
            if IsPedInAnyVehicle(player, false) then
                if dist2 > 5 then
                    DrawMissionText('Åk tillbaka till Elias med fordonet', 0.96, 0.5)
                    if not DoesBlipExist(deliveryPos) then
                        deliveryPos = AddBlipForCoord(Config.EliasDeliveryPos)
                        BlipDetails(deliveryPos, 'Leveransposition', 46, true)
                    end
                else
                    if dist2 >= 3 and dist2 <= 10 then
                        DrawMarker(36, Config.EliasDeliveryPos, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 255, 0, 0, 100, false, true, 2, false, false, false, false)
                    end
                    if dist2 < 3 then
                        DrawMarker(36, Config.EliasDeliveryPos, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 0, 255, 0, 100, false, true, 2, false, false, false, false)
                    end
                    DrawMissionText('Åk tillbaka till Elias med fordonet', 0.96, 0.5)
                    if IsControlJustPressed(1, 38) then
                        missionDone = true
                        ESX.ShowNotification('Tack som fan, kom tillbaka för din belöning')
                        TaskLeaveVehicle(player, targetVehicle5, 0)
                        SetVehicleDoorsLockedForAllPlayers(targetVehicle5, true)
                        RemoveBlip(deliveryPos)
                        if not DoesBlipExist(eliasPos) then
                            eliasPos = AddBlipForCoord(Config.EliasPos)
                            BlipDetails(eliasPos, 'Elias', 46, true)
                        end
                    end
                end
            else
                DrawMissionText('Hoppa in i fordonet', 0.96, 0.5)
            end
        end

        if dist3 < 2 then
            if IsControlJustPressed(1, 38) then
                ESX.ShowNotification('Jag har hört att Rodriguez kan behöva hjälp med lite jobb, kontakta honom')
                TriggerServerEvent('zyke_uppdragGiveReward', level, Config.Reward5, 5, extraBonus) -- Fixa timer osv
                ESX.TriggerServerCallback('zyke_uppdragLevelElias', function(result) level = result end)
                if level < 6 then
                    TriggerServerEvent('zyke_uppdragUpdateLevelElias', 6)
                    ESX.ShowNotification('Du kan nu acceptera nya uppdrag')
                end
                forceStop = true
            end
        end

        if forceStop then
            RemoveBlip(findVehicleArea5)
            RemoveBlip(deliveryPos)
            RemoveBlip(eliasPos)
            DeleteVehicle(targetVehicle5)
            lockpickPercentage = 0
            hasAttemptedLockpicking = false
            currentlyLockpicking = false
            hasLockpicked = false
            missionDone = false
            jobCompleted = true
            jobStarted = false
            forceStop = false
            canPressAgain = true
        end
    end
end)

RegisterNetEvent('zyke_uppdragMainEvent5Timer')
AddEventHandler('zyke_uppdragMainEvent5Timer', function()
    Wait(200)
    canPressAgain = true
end)

-- Rodriguez Uppdrag 1:
RegisterNetEvent('zyke_uppdragUppdrag1_4Dialogue')
AddEventHandler('zyke_uppdragUppdrag1_4Dialogue', function()
    while not jobCompleted do
        Wait(1)
        if justAccepted then
            justAccepted = false
            ESX.ShowNotification('Jag läste genom de papperna du gav mig.')
            Wait(2000)
            ESX.ShowNotification('Tydligen blir det en drogtransport och jag vill att du baxar lastbilen')
            Wait(3000)
            ESX.ShowNotification('Ta dig upp till klubben och följ efter lastbilen')
            Wait(2000)
            ESX.ShowNotification('Vänta till de har tagit sig mötesplatsen')
            Wait(2000)
            ESX.ShowNotification('Vid rätt tillefälle, baxa lastbilen och kör hit den')
            Wait(3000)
            ESX.ShowNotification('Jag har hört att de har tabbar')
        end
    end
end)
-- Göra så man får mer droger om man har gjort uppdrag 3 precis innan, typ
-- Nämna att uppdraget ska köras solo, speciellt när jag tar lastbilen för att minimera uppmärksamheten
-- Fixa så det måste vara ett antal poliser för att köra denna då man tjänar jävligt bra på uppdraget

RegisterNetEvent('zyke_uppdragMainEvent1_4')
AddEventHandler('zyke_uppdragMainEvent1_4', function() -- Fixa heading i uppdrag 3 med lastbilen
    forceStop = false
    while not jobCompleted do
        Wait(1)

        local player = GetPlayerPed(-1)
        local pCoords = GetEntityCoords(player)
        local targetTruckCoords = GetEntityCoords(targetTruck)
        local targetPed1Coords = GetEntityCoords(targetPed1)
        local targetPed2Coords = GetEntityCoords(targetPed2)
        local settings1 = Config.TargetPedSettings1_2_1
        local settings2 = Config.TargetPedSettings1_2_2
        local settings3 = Config.TargetPedSettings1_2_3
        local settings4 = Config.TargetPedSettings1_2_4
        local dist1 = #(pCoords - Config.TargetVehiclePos1_2)
        local dist2 = #(targetTruckCoords - Config.Destination1_2)
        local dist3 = #(targetPed1Coords - Config.TargetVehiclePos1_2)
        local dist4 = #(targetPed2Coords - Config.TargetVehiclePos1_2)
        local dist5 = #(pCoords - Config.Destination1_2)
        local dist6 = #(pCoords - targetPed1Coords)
        local dist7 = #(pCoords - targetTruckCoords)
        local dist8 = #(pCoords - Config.DeliverPosition1_2)
        local dist9 = #(pCoords - Config.RodriguezPos)

        if not followMessage_1_4 and not DoesEntityExist(targetPed1) and not returnMessage_4 then
            DrawMissionText('Åk tillbaka till baren', 0.96, 0.5)
            if not DoesBlipExist(followTruck) then
                followTruck = AddBlipForCoord(Config.TargetVehiclePos1_2)
                BlipDetails(followTruck, 'Lastbilen', 46, true)
            end
        end


        if dist1 < 150 then
            if not vehicleSpawned_4 then
                RequestModel(Config.TruckVehicleModel1_2) while not HasModelLoaded(Config.TruckVehicleModel1_2) do Wait(10) end
                targetTruck = CreateVehicle(Config.TruckVehicleModel1_2, Config.TargetVehiclePos1_2, Config.TruckVehicleHeading1_2, true, true)
                vehicleSpawned_4 = true
            end
            if dist1 < 50 then
                if not DoesEntityExist(targetPed1) then
                    RequestModel(settings1.Hash) while not HasModelLoaded(settings1.Hash) do Wait(10) end
                    RequestModel(settings2.Hash) while not HasModelLoaded(settings2.Hash) do Wait(10) end
                    targetPed1 = CreatePed(4, settings1.Hash, settings1.x, settings1.y, settings1.z, settings1.h, false, true) table.insert(pedCommandsUppdrag1_4, targetPed1)
                    targetPed2 = CreatePed(4, settings2.Hash, settings2.x, settings2.y, settings2.z, settings2.h, false, true) table.insert(pedCommandsUppdrag1_4, targetPed2)
                    NetworkRegisterEntityAsNetworked(peds)
                    if not DoesRelationshipGroupExist('Lost') then
                        AddRelationshipGroup('Lost')
                    end
                    SetPedRelationshipGroupHash(player, GetHashKey("Player"))
                    hasSpawned_4 = true
                    for _,peds in pairs(pedCommandsUppdrag1_4) do
                        TaskGoToCoordAnyMeans(peds, Config.TargetVehiclePos1_2, 1.0, false)
                        SetPedRelationshipGroupHash(peds, GetHashKey("Lost"))
                        SetRelationshipBetweenGroups(0, GetHashKey("Lost"), GetHashKey("Lost"))
                        NetworkRegisterEntityAsNetworked(peds)
                    end
                    RemoveBlip(followTruck)
                end
            end
        end

        if not IsPedInAnyVehicle(targetPed1, false) then
            if dist3 < 40 and not followMessage_1_4 and not canEngage then
                waitToEnterVehicleText = true
                if dist3 < 5 then
                    if dist4 < 5 then
                        for _,peds in pairs(pedCommandsUppdrag1_4) do
                            -- ClearPedTasksImmediately(peds)
                            if not hasEnteredVehicle then
                                waitToEnterVehicleText = true
                                TaskEnterVehicle(targetPed1, targetTruck, -1, -1, 1.0, 1, 0)
                                TaskEnterVehicle(targetPed2, targetTruck, -1, 0, 1.0, 1, 0)
                                hasEnteredVehicle = true
                                followMessage_1_4 = true
                                displayFollowMessage_4 = true
                            end
                        end
                    end
                end
            end
        end

        if waitToEnterVehicleText then
            DrawMissionText('Vänta på att de hoppar in i lastbilen', 0.96, 0.5)
        end

        if displayFollowMessage_4 and IsPedInAnyVehicle(targetPed1, false) then
            DrawMissionText('Följ efter lastbilen ~y~diskret~s~, ~r~åk inte~s~ för nära', 0.96, 0.5)
            waitToEnterVehicleText = false
        end
        
        if IsPedInAnyVehicle(targetPed1, false) and IsPedInAnyVehicle(targetPed2, false) and not startedDriving then
            startedDriving = true
            TaskVehicleDriveToCoordLongrange(targetPed1, targetTruck, Config.Destination1_2, 20.0, 387, 5)
        end

        if dist2 < 150 and not startedParking then
            startedParking = true
            ClearPedTasks(targetPed1)
            ClearPedSecondaryTask(targetPed1)
            TaskVehiclePark(targetPed1, targetTruck, Config.Destination1_2, Config.DeliverPosition1_2, 0, 40.0, false)
        end

        if dist2 < 100 then
            if not spawnedDeliveryGuards then
                if not DoesEntityExist(targetPed3) then
                    RequestModel(settings3.Hash) while not HasModelLoaded(settings3.Hash) do Wait(10) end
                    RequestModel(settings4.Hash) while not HasModelLoaded(settings4.Hash) do Wait(10) end
                    targetPed3 = CreatePed(4, settings3.Hash, settings3.x, settings3.y, settings3.z, settings3.h, false, true) table.insert(pedCommandsUppdrag1_4, targetPed3)
                    targetPed4 = CreatePed(4, settings4.Hash, settings4.x, settings4.y, settings4.z, settings4.h, false, true) table.insert(pedCommandsUppdrag1_4, targetPed4)
                    for _,peds in pairs(pedCommandsUppdrag1_4) do
                        NetworkRegisterEntityAsNetworked(peds)
                        SetPedRelationshipGroupHash(peds, GetHashKey("Lost"))
                        spawnedDeliveryGuards = true
                        applyPedSettings = true
                    end
                end
            end
        end

        if applyPedSettings then
            for _,peds in pairs(pedCommandsUppdrag1_4) do
                GiveWeaponToPed(peds, GetHashKey('weapon_compactrifle'), false, true)
                SetCurrentPedWeapon(peds, GetHashKey('weapon_compactrifle'), true)
                SetPedCombatAttributes(peds, 46, 1)
                SetPedCombatAbility(peds, 100)
                SetPedCombatMovement(peds, 3)
                SetPedSeeingRange(peds, 100000000.0)
                SetPedHearingRange(peds, 100000000.0)
                SetPedAccuracy(peds, Config.Accuracy)
                SetPedArmour(peds, Config.Armor)
                applyPedSettings = false
            end
        end

        if dist5 < 75 then
            followMessage_1_4 = false
            if dist5 < 70 then
                canEngage = true
                displayFollowMessage_4 = false
            end
        end

        if canEngage then
            for _,peds in pairs(pedCommandsUppdrag1_4) do
                if IsPedInAnyVehicle(peds) then
                    if dist2 < 5 then
                        FreezeEntityPosition(targetTruck, true)
                        TaskLeaveVehicle(peds, targetTruck, 0)
                        Wait(100)
                        TaskWanderStandard(peds, 1, 10)
                    end
                end
            end
            if not hasSetAggression then
                SetRelationshipBetweenGroups(5, GetHashKey("Lost"), GetHashKey("Player"))
                SetRelationshipBetweenGroups(5, GetHashKey("Player"), GetHashKey("Lost"))
                hasSetAggression = true
                SetVehicleDoorsLockedForAllPlayers(targetTruck, true)
            end
        else
            if not hasStartedCheckingDeaths then
                TriggerEvent('zyke_zyke_uppdragMainEvent4CheckGuardDeaths')
                hasStartedCheckingDeaths = true
            end
        end

        if not IsEntityDead(targetPed1) and not IsEntityDead(targetPed2) and not IsEntityDead(targetPed3) and not IsEntityDead(targetPed4) then
            allPedsKilled = false
        else
            allPedsKilled = true
        end

        if dist5 > 75 and dist2 < 10 and not allPedsKilled and not followMessage_1_4 then
            if canEngage then
                DisableControlAction(1, 24, true)
            else
                DrawMissionText('Går närmare och skjut dem, försök dra åt dig så lite uppmärksamhet som möjligt', 0.96, 0.5)
            end
        end

        -- for _,peds in pairs(pedCommandsUppdrag1_4) do -- Måste fixa RegisterEvent med stor delay för annars laggar det skitmycket
        --     deathCause = GetPedSourceOfDeath(peds)
        --     if deathCause ~= player then
        --         ESX.ShowNotification('bababooey')
        --     else
        --         ESX.ShowNotification('inte bababooey')
        --     end
        -- end

        if IsEntityDead(targetPed1) then
            if dist6 < 3 and not hasLootedKey and canEngage then
                DrawText3Ds(targetPed1Coords.x, targetPed1Coords.y, targetPed1Coords.z, '[~g~E~w~] Sök genom', 0.4)
                if IsControlJustPressed(1, 38) then
                    TriggerServerEvent('zyke_uppdragItemChance', 4)
                    hasLootedKey = true
                    hasKey = true
                    Wait(200)
                    ESX.ShowNotification('Du plockade upp en nyckel')
                end
            end
        end

        if dist7 < 10 and hasKey then -- Fixa så det är vid dörren istället, kanske
            DrawText3Ds(targetTruckCoords.x, targetTruckCoords.y, targetTruckCoords.z+3, '[~g~E~w~] Lås upp fordonet', 1.0)
            if dist7 < 5 then
                if IsControlJustPressed(1, 38) then
                    SetVehicleDoorsLockedForAllPlayers(targetTruck, false)
                    FreezeEntityPosition(targetTruck, false)
                    hasKey = false
                    vehicleUnlocked = true
                end
            end
        end

        if GetVehiclePedIsIn(player, false) == targetTruck then
            returnMessage_4 = true
        end

        if returnMessage_4 and dist8 > 5 and not isMissionDone then
            DrawMissionText('Åk med lastbilen till destinationen, polisen ~y~kan vara~s~ meddelade om ditt fordon', 0.96, 0.5)
            if not DoesBlipExist(deliverPosition4_2) then
                deliverPosition4_2 = AddBlipForCoord(Config.DeliverPosition1_2)
                BlipDetails(deliverPosition4_2, 'Lämna lastbilen', 46, true)
            end
        elseif returnMessage_4 and dist8 < 5 and not isMissionDone then
            DrawMissionText('Lämna in fordonet', 0.96, 0.5)
        end

        if dist8 < 20 and returnMessage_4 and not isMissionDone then
            DrawMarker(36, Config.DeliverPosition1_2, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 30, 144, 255, 100, false, true, 2, false, false, false, false)
            if dist8 < 5 then
                if IsControlJustPressed(1, 38) then
                    if IsPedInAnyVehicle(player, false) then
                        if GetVehiclePedIsIn(player, false) == targetTruck then
                            TaskLeaveVehicle(player, targetTruck, 0)
                            RemoveBlip(deliverPosition4_2)
                            SetVehicleDoorsLockedForAllPlayers(targetTruck, true)
                            ESX.ShowNotification('Tack för hjälpen, kom tillbaka till mig för din belöning')
                            rodriguezBlip4 = AddBlipForCoord(Config.RodriguezPos)
                            BlipDetails(rodriguezBlip4, 'Rodriguez', 46, true)
                            isMissionDone = true
                            missionDone = true
                        else
                            ESX.ShowNotification('Fel fordon')
                        end
                    else
                        ESX.ShowNotification('Du måste sitta i fordonet')
                    end
                end
            end
        end

        if isMissionDone then
            if dist9 < 3 then
                if IsControlJustPressed(1, 38) then
                    TriggerServerEvent('zyke_uppdragGiveReward', level, Config.Reward1_2, 1, extraBonus, true) -- Fixa timer osv
                    ESX.TriggerServerCallback('zyke_uppdragLevel', function(result) level = result end)
                    if level < 2 then
                        TriggerServerEvent('zyke_uppdragUpdateLevelRodriguez', 2)
                        ESX.ShowNotification('Du kan nu acceptera nya uppdrag')
                    end
                    forceStop = true
                end
            end
        end

        if forceStop then
            hasStartedCheckingDeaths = false
            hasSetAggression = false
            canEngage = false
            applyPedSettings = false
            spawnedDeliveryGuards = false
            vehicleSpawned_4 = false
            jobCompleted = true
            jobStarted = false
            forceStop = false
            hasEnteredVehicle = false
            startedParking = false
            hasLootedKey = false
            hasKey = false
            followMessage_1_4 = false
            allPedsKilled = false
            isMissionDone = false
            missionDone = false
            returnMessage_4 = false
            hasSpawned_4 = false
            vehicleUnlocked = false
            startedDriving = false
            waitToEnterVehicleText = false
            DeleteVehicle(targetTruck)
            RemoveBlip(followTruck)
            RemoveBlip(deliverPosition4_2)
            RemoveBlip(rodriguezBlip4)
            SetRelationshipBetweenGroups(3, GetHashKey("Lost"), GetHashKey("Player"))
            SetRelationshipBetweenGroups(3, GetHashKey("Player"), GetHashKey("Lost"))
            for _,peds in pairs(pedCommandsUppdrag1_4) do
                DeletePed(peds)
            end
        end
    end
end)

RegisterNetEvent('zyke_zyke_uppdragMainEvent4CheckGuardDeaths')
AddEventHandler('zyke_zyke_uppdragMainEvent4CheckGuardDeaths', function()
    while not canEngage do
        Wait(1000)
        if hasSpawned_4 then
            if not IsEntityDead(targetPed1) and not IsEntityDead(targetPed2) then
                if DoesEntityExist(targetPed3) then
                    if not IsEntityDead(targetPed3) and not IsEntityDead(targetPed4) then
                        -- ESX.ShowNotification('Inte döda')
                    else
                        -- ESX.ShowNotification('Döda 2')
                        forceStop = true
                        killedGuardsEarly = true
                        -- LoseLevel('rodriguez')
                        CancelMission('rodriguez')
                    end
                end
            else
                -- ESX.ShowNotification('Döda 1')
                forceStop = true
                killedGuardsEarly = true
                -- LoseLevel('rodriguez')
                CancelMission('rodriguez')
            end
        end
    end
end)

-- Rodriguez Uppdrag 1:
RegisterNetEvent('zyke_uppdragUppdrag2_2Dialogue')
AddEventHandler('zyke_uppdragUppdrag2_2Dialogue', function()
    while not jobCompleted do
        Wait(1)
        if justAccepted then
            justAccepted = false
            ESX.ShowNotification('Jag har lite uppgifter till dig')
            Wait(2000)
            ESX.ShowNotification('Anton planerar ett stort jobb och behöver en bepransad bil och lite varor')
            Wait(3000)
            ESX.ShowNotification('Checka GPS:en för addresserna, lös allting, och kom tillbaka')
        end
    end
end)

RegisterNetEvent('zyke_uppdragMainEvent2_2')
AddEventHandler('zyke_uppdragMainEvent2_2', function() -- Fixa heading i uppdrag 3 med lastbilen
    forceStop = false
    while not jobCompleted do
        Wait(1)

        local player = GetPlayerPed(-1)
        local pCoords = GetEntityCoords(player)
        local dist1 = #(pCoords - Config.VehicleTunePos2_2)
        local dist2 = #(pCoords - Config.PickupCratesPos2_2)
        local dist3 = #(pCoords - Config.RodriguezDeliveryPos)
        local dist4 = #(pCoords - Config.RodriguezPos)

        if not DoesEntityExist(vehicleToDeliver) then
            if not hasDelivered then
                RequestModel(Config.VehicleToUpgrade2_2) while not HasModelLoaded(Config.VehicleToUpgrade2_2) do Wait(10) end
                vehicleToDeliver = CreateVehicle(Config.VehicleToUpgrade2_2, Config.VehicleToDeliverSpawn2_2, Config.VehicleToDeliverHeading2_2, true, true)
                if not DoesBlipExist(deliverBlip) then
                    deliverBlip = AddBlipForCoord(Config.VehicleTunePos2_2)
                    BlipDetails(deliverBlip, 'Leveransposition', 46, true)
                end
                SetVehicleColours(vehicleToDeliver, 12, 12)
                SetVehicleWindowTint(vehicleToDeliver, 'WINDOWTINT_PURE_BLACK')
                SetVehicleNumberPlateText(vehicleToDeliver, 'yeye')
                SetVehicleDirtLevel(vehicleToDeliver, 0.0)
            end
        end

        if not hasDelivered then
            if dist1 >= 3 and dist1 <= 10 then
                DrawMarker(36, Config.VehicleTunePos2_2, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 255, 0, 0, 100, false, true, 2, false, false, false, false)
            end
            if dist1 < 3 then
                DrawMarker(36, Config.VehicleTunePos2_2, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 0, 255, 0, 100, false, true, 2, false, false, false, false)
                ESX.ShowHelpNotification('~INPUT_CONTEXT~ Lämna in fordonet')
                if IsControlJustPressed(1, 38) then
                    if GetVehiclePedIsIn(player, false) == vehicleToDeliver then
                        hasDelivered = true
                        TaskLeaveVehicle(player, vehicleToDeliver, 0.0)
                        SetVehicleDoorsLockedForAllPlayers(vehicleToDeliver, true)
                        ESX.ShowNotification('Kom tillbaka om fem minuter')
                        RemoveBlip(deliverBlip)
                        Wait(30000)
                        ESX.ShowNotification('Kom tillbaka och hämta den modifierade bilen')
                        finishedModifying = true
                        RequestModel(Config.VehicleToDeliver2_2) while not HasModelLoaded(Config.VehicleToDeliver2_2) do Wait(10) end
                        modifiedVehicle = CreateVehicle(Config.VehicleToDeliver2_2, Config.VehicleTunePos2_2, Config.VehicleTuneHeading2_2, true, true)
                        DeleteVehicle(vehicleToDeliver)
                        SetVehicleColours(modifiedVehicle, 12, 12)
                        SetVehicleWindowTint(modifiedVehicle, 'WINDOWTINT_PURE_BLACK')
                        SetVehicleNumberPlateText(modifiedVehicle, 'yeye')
                        SetVehicleDirtLevel(modifiedVehicle, 0.0)
                    else
                        ESX.ShowNotification('Du sitter i fel fordon')
                    end
                end
            end
        end

        if finishedModifying and not hasPickedUpVehicle then
            if GetVehiclePedIsIn(player) == modifiedVehicle then
                hasPickedUpVehicle = true
                ESX.ShowNotification('Jag behöver även lite varor uppe från Paleto, åk och hämta dem åt mig')
                cratesToPickUp = AddBlipForCoord(Config.PickupCratesPos2_2)
                BlipDetails(cratesToPickUp, 'Varor', 46, true)
            end
        end

        if not hasPickedUpCrates and finishedModifying then
            if dist2 >= 1 and dist2 <= 10 then
                DrawMarker(25, Config.PickupCratesPos2_2, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 255, 0, 0, 100, false, true, 2, false, false, false, false)
            end
            if dist2 < 1.5 then
                ESX.ShowHelpNotification('~INPUT_CONTEXT~ Plocka upp varorna')
                DrawMarker(25, Config.PickupCratesPos2_2, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 0, 255, 0, 100, false, true, 2, false, false, false, false)
                if IsControlJustPressed(1, 38) then
                    if not IsPedInAnyVehicle(player, false) then
                        ESX.ShowNotification('Test')
                        hasPickedUpCrates = true
                        returnBlip = AddBlipForCoord(Config.RodriguezDeliveryPos)
                        BlipDetails(returnBlip, 'Rodriguez', 46, true)
                        ESX.ShowNotification('Återvänd till Rodriguez med bilen och varorna')
                        RemoveBlip(cratesToPickUp)
                        returnToRodriguez = true
                    else
                        ESX.ShowNotification('Hoppa ut ur fordonet din lata jävel')
                    end
                end
            else
                if finishedModifying and GetVehiclePedIsIn(player, false) == modifiedVehicle then
                    DrawMissionText('Hämta varorna som är utmarkerade på GPS:en', 0.96, 0.5)
                end
            end
        end

        if returnToRodriguez then
            if dist3 >= 3 and dist3 <= 10 then
                DrawMarker(36, Config.RodriguezDeliveryPos, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 255, 0, 0, 100, false, true, 2, false, false, false, false)
            end
            if dist3 < 3 then
                ESX.ShowHelpNotification('~INPUT_CONTEXT~ Lämna in fordonet')
                DrawMarker(36, Config.RodriguezDeliveryPos, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 0, 255, 0, 100, false, true, 2, false, false, false, false)
                if IsControlJustPressed(1, 38) then
                    missionDone = true
                    ESX.ShowNotification('Prata med Rodriguez')
                    SetVehicleDoorsLockedForAllPlayers(modifiedVehicle, true)
                    TaskLeaveVehicle(player, modifiedVehicle, 0)
                    returnToRodriguez = false
                end
            end
        end

        if dist4 < 3 and missionDone then
            if IsControlJustPressed(1, 38) then
                forceStop = true
                TriggerServerEvent('zyke_uppdragGiveReward', level, Config.Reward4, 2, extraBonus) -- Fixa timer osv
                ESX.TriggerServerCallback('zyke_uppdragLevelRodriguez', function(result) level = result end)
                if level < 3 then
                    TriggerServerEvent('zyke_uppdragUpdateLevelRodriguez', 3)
                    ESX.ShowNotification('Du kan nu acceptera nya uppdrag')
                end
            end
        end

        if forceStop then
            hasDelivered = false
            missionDone = false
            jobStarted = false
            jobCompleted = true
            hasPickedUpCrates = false
            finishedModifying = false
            returnToRodriguez = false
            hasPickedUpVehicle = false
            DeleteVehicle(vehicleToDeliver)
            DeleteVehicle(modifiedVehicle)
            RemoveBlip(deliverBlip)
            RemoveBlip(cratesToPickUp)
            RemoveBlip(returnBlip)
        end
    end
end)

-- RegisterNetEvent('zyke_uppdragMainEvent3TooClose')
-- AddEventHandler('zyke_uppdragMainEvent3TooClose', function()
--     while countDown do
--         Wait(1)

--         DrawMissionText('Akta dig: ' .. countDownTimer .. '', 0.96, 0.5)
--         Wait(100)
--         countDownTimer = countDownTimer - 0.1

--         if countDownTimer == 0 then
--             ESX.ShowNotification('noob')
--             -- Fail()
--         end
--     end
-- end)

-- Uppdrag 5
-- Kanske ska råna någon, trycka E och sedan finns det en chans att personen springer efter dig med kniv / pistol, sedan kommer det kanske fler runt hörnet i en bil som jagar dig
-- Tryck E för att råna personen och sedan följer pedden efter dig och kallar på några i fordon och jagar dig
-- Kan sätta en wander på target
-- Efter man har åkt till Elias kan det stå att man även måste åka till ett annat ställe för det var inte tillräckligt mycket med produkter.
-- Skriv med att man ska vara tyst när man gör det så folk inte skjuter.
RegisterNetEvent('zyke_uppdragMainEvent7')
AddEventHandler('zyke_uppdragMainEvent7', function()
    forceStop = false
    while not jobCompleted do
        Wait(5)
        local player = GetPlayerPed(-1)
        local pCoords = GetEntityCoords(player)
        local targetPedHash = GetHashKey(Config.TargetPedName5)
        local TargetPedPos7 = Config.TargetPedPos7[math.random(#Config.TargetPedPos7)]
        local targetCoords = GetEntityCoords(targetPed)
        local death = GetPedCauseOfDeath(targetPed)
        local dist1 = #(pCoords - targetCoords)
        local dist2 = #(pCoords - Config.BlipLocation7)
        local backupVehicleName = 'granger'

        if targetSpawned == false then
            RequestModel(targetPedHash)
            RequestAnimDict(dict)
            while not HasModelLoaded(targetPedHash) do Wait(5) end
            targetPed = CreatePed(4, targetPedHash, TargetPedPos3.x, TargetPedPos3.y, TargetPedPos3.z, Config.TargetPedHeading5, false, true)
            SetPedComponentVariation(targetPed, 3, 0, 0, 0) -- Tröja (0 vilken tröja, andra 0 = färgen)
            SetPedComponentVariation(targetPed, 4, 0, 2, 0) -- Byxor (0 = vilka byxor, 2 = färgen)
            SetPedComponentVariation(targetPed, 0, 0, 0, 0) -- Skägg (0 = vilket skägg, alltså inget)
            targetSpawned = true
        end
        -- Göra ett script där man bara behöver lägga in pednamnet och sedan får man se allting (zyke_pedcomponents)
        -- drawables = GetNumberOfPedDrawableVariations(targetPed, 0)
        -- drawables2 = GetPedDrawableVariation(targetPed, 1)
        -- ESX.ShowNotification('' .. drawables .. '')

        local targetHealth = GetEntityHealth(targetPed)
        local targetCoords = GetEntityCoords(targetPed)

        if not blipSpawned then
            mainBlip = AddBlipForRadius(Config.BlipLocation7.x, Config.BlipLocation7.y, Config.BlipLocation7.z, 150.0)
            -- SetBlipSprite(blip, 1)
            SetBlipColour(mainBlip, 5)
            SetBlipAlpha(mainBlip, 150)
            blipSpawned = true
        end

        if dist2 < 150 and not hasRobbed then
            DrawMissionText('Leta reda på en individ med svart-röda kläder', 0.96, 0.5)
        end

        if dist1 < 1.5 and not hasRobbed and IsControlJustPressed(1, 38) then
            hasRobbed = true
            DrawMissionText('Fly från platsen', 0.96, 0.5)
            hasBackupSpawned = false
        end

        if hasRobbed then
            canKill = true
            if hasFled then
                DrawMissionText('Åk tillbaka till Elias', 0.96, 0.5)
            else
                DrawMissionText('Fly från platsen', 0.96, 0.5)
            end
        end

        if IsEntityDead(targetPed) and not alreadyDead then
            if canKill then
                -- Debug
                -- local deathCause = GetPedCauseOfDeath(targetPed)
                -- Wait(50)
                -- ESX.ShowNotification('' .. deathCause .. '')
                if checkArray (allowedWeapons, death) then
                    ESX.ShowNotification('Kan döda')
                else
                    forceStop = true
                    shotPedUppdrag7 = true
                    CancelMission()
                    causeConfirmed = true
                end
                alreadyDead = true
            else
                killEarlyUppdrag1 = true
                CancelMission()
                forceStop = true
            end
            if not IsEntityDead(targetPed) then
                alreadyDead = false
            end
        end

        local backupHash1 = 'a_m_y_cyclist_01'
        local backupHash2 = 'a_m_m_soucent_03'
        local backupHash3 = 'a_m_m_soucent_04'
        local backupHash4 = 'a_m_y_beach_03'
        if not hasBackupSpawned then
            RequestModel(backupHash1) while not HasModelLoaded(backupHash1) do Wait(10) end
            RequestModel(backupHash2) while not HasModelLoaded(backupHash2) do Wait(10) end
            RequestModel(backupHash3) while not HasModelLoaded(backupHash3) do Wait(10) end
            RequestModel(backupHash4) while not HasModelLoaded(backupHash4) do Wait(10) end
            RequestModel(backupVehicleName) while not HasModelLoaded(backupVehicleName) do Wait(10) end
            backup1 = CreatePed(4, targetPedHash, TargetPedPos3.x2, TargetPedPos3.y2, TargetPedPos3.z2, 0, false, true) table.insert(pedCommands, backup1)
            backup2 = CreatePed(4, targetPedHash, TargetPedPos3.x2, TargetPedPos3.y2, TargetPedPos3.z2, 0, false, true) table.insert(pedCommands, backup2)
            backup3 = CreatePed(4, targetPedHash, TargetPedPos3.x2, TargetPedPos3.y2, TargetPedPos3.z2, 0, false, true) table.insert(pedCommands, backup3)
            backup4 = CreatePed(4, targetPedHash, TargetPedPos3.x2, TargetPedPos3.y2, TargetPedPos3.z2, 0, false, true) table.insert(pedCommands, backup4)
            AddRelationshipGroup('BackupPeds')
            for _,peds in pairs(pedCommands) do
                for _,weapons in pairs(givePedWeapons) do
                    weaponToGiveTest = givePedWeapons[math.random(1, #weapons)] -- Måste nog ändra nollan till 1 för att fixa skiten
                    -- local weaponToGiveTest = givePedWeapons[math.random(0, #givePedWeapons)]
                    GiveWeaponToPed(peds, GetHashKey(weaponToGiveTest), false, true)
                    SetPedCombatAttributes(peds, 46, 1)
                    SetPedCombatAbility(peds, 100)
                    SetPedCombatMovement(peds, 3)
                    SetPedSeeingRange(peds, 100000000.0)
                    SetPedHearingRange(peds, 100000000.0)
                    SetPedAccuracy(peds, 35)
                    SetPedRelationshipGroupHash(peds, GetHashKey("BackupPeds"))
                    SetPedRelationshipGroupHash(player, GetHashKey("Player"))
                    SetRelationshipBetweenGroups(0, GetHashKey("BackupPeds"), GetHashKey("BackupPeds"))
                    SetRelationshipBetweenGroups(5, GetHashKey("BackupPeds"), GetHashKey("Player"))
                    SetRelationshipBetweenGroups(5, GetHashKey("Player"), GetHashKey("BackupPeds"))
                end
                if not vehicleSpawned then
                    backupVehicle = CreateVehicle(GetHashKey(backupVehicleName), TargetPedPos3.x2, TargetPedPos3.y2, TargetPedPos3.z2, Config.VehicleHeading5, true, true)
                    TaskWarpPedIntoVehicle(backup1, backupVehicle, -1)
                    TaskWarpPedIntoVehicle(backup2, backupVehicle, 0)
                    TaskWarpPedIntoVehicle(backup3, backupVehicle, 1)
                    TaskWarpPedIntoVehicle(backup4, backupVehicle, 2)
                    -- SetTaskVehicleChaseBehaviorFlag(backup1, 1, -1)
                    vehicleSpawned = true
                end
                Wait(10)
                if IsPedInAnyVehicle(backup1, false) then
                    if not startedChasing then
                        ESX.ShowNotification('test')
                        TaskVehicleDriveToCoordLongrange(backup1, backupVehicle, pCoords.x, pCoords.y, pCoords.z, 20.0, 6, 5)
                        TaskVehicleChase(backup1, player)
                        TaskVehicleChase(backup2, player)
                        TaskVehicleChase(backup3, player)
                        TaskVehicleChase(backup4, player)
                        startedChasing = true
                    end
                else
                    ESX.ShowNotification('bababooey')
                end
            end
            hasBackupSpawned = true
        end

        if hasRobbed then
            if not backupVehicleBlipSpawned then
                while not HasModelLoaded(backupVehicleName) do Wait(10) end
                backupVehicleBlip = AddBlipForEntity(backupVehicle)
                backupVehicleBlipSpawned = true
            end
            if not hasFled then
                if not startedChasing then
                    if IsPedInAnyVehicle(backup1, false) then
                        ESX.ShowNotification('yeet')
                        TaskDriveBy(backup1, player, backupVehicle, pCoords.x, pCoords.y, pCoords.z, 10.0, 75, 0, 0)
                        startedChasing = true
                    end
                end
            end
        end

        if forceStop then
            killFarAwayUppdrag7 = false
            killCloseUppdrag7 = false
            canKill = false
            blipSpawned = false
            backupVehicleBlipSpawned = false
            targetSpawned = false
            jobCompleted = true
            removedBlip = false
            vehicleSpawned = false
            RemoveBlip(mainBlip)
            RemoveBlip(blip)
            RemoveBlip(backupVehicleBlip)
        end

    end
end)

-- RegisterCommand('zykeyes', function()
--     local player = GetPayerPed(-1)
--     Get
-- end)

-- Citizen.CreateThread(function()
--     while true do
--         Wait(50)
--         if not missionStarted then
--             TriggerEvent('zyke_uppdragErbjudande', source)
--             missionStarted = true
--         end
--     end
-- end)

local wantedItemList = {
    'två knivar',
    'några magasin',
    'några granater'
}

RegisterNetEvent('zyke_uppdragErbjudande', function()
    while not jobCompleted do
        Wait(1)

        local player = GetPlayerPed(-1)
        local pCoords = GetEntityCoords(player)
        local dist1 = #(pCoords - Config.BlipCoordsSpecial)
        local dist2 = #(pCoords - Config.EliasPos)
        local dist3 = #(pCoords - Config.ChangeBlip)

        for _,item in pairs(wantedItemList) do
            if randomItem == nil then
                randomItem = wantedItemList[math.random(1, #wantedItemList)]
                -- print(randomItem) -- Debug för jag kan inte scripta
            end
        end

        if not blipSpawned then
            searchBlip = AddBlipForCoord(Config.BlipCoordsSpecial.x, Config.BlipCoordsSpecial.y, Config.BlipCoordsSpecial.z)
            SetBlipColour(searchBlip, 46)
            blipSpawned = true
        end
        if dist3 < 10 and searchArea == nil then
            ESX.ShowNotification('Leta noga inom området')
            RemoveBlip(searchBlip)
            searchArea = AddBlipForRadius(Config.BlipCoordsSpecial.x, Config.BlipCoordsSpecial.y, Config.BlipCoordsSpecial.z, Config.BlipCoordsSpecialRadius)
            SetBlipColour(searchArea, 46)
            SetBlipAlpha(searchArea, 125)
        end

        if not collectedMaterials then
            if dist1 < 2  then
                DrawText3Ds(Config.BlipCoordsSpecial.x, Config.BlipCoordsSpecial.y, Config.BlipCoordsSpecial.z, '[~g~E~w~]', 0.4) -- Fixa props kanske?
                if dist1 < 1 then
                    if IsControlJustPressed(0, 38) then
                        RemoveBlip(searchArea)
                        collectedMaterials = true
                        ESX.ShowNotification('Du plockade upp ' .. randomItem .. '.')
                    end
                end
            end
        else
            if dist2 < 2 then
                RemoveBlip(eliasBlip)
                eliasBlip = nil
                if IsControlJustPressed(0, 38) then
                    ESX.ShowNotification('Tack för produkterna, här får du en stor belöning.') -- Fixa belöning
                    forceStop = true
                end
            else
                DrawMissionText('Åk och lämna varorna till Elias', 0.96, 0.5) -- Kanske fixa så man endast får uppdraget om Elias är på en speciell position som man själv har gjort uppdrag vid förut? Eller inte, lol.
                -- if isEliasBlipRemoved then
                if eliasBlip == nil then
                    eliasBlip = AddBlipForCoord(Config.EliasPos)
                    BlipDetails(eliasBlip, 'Elias', 46, true)
                end
            end
        end

        if forceStop then
            jobCompleted = true
            blipSpawned = false
            randomItem = nil
            collectedMaterials = false
            RemoveBlip(searchArea)
        end
    end
end)

function BlipDetails(blipName, blipText, color, route)
    -- https://docs.fivem.net/docs/game-references/blips/#BlipColors
    BeginTextCommandSetBlipName("STRING")
    SetBlipColour(blipName, color)
    AddTextComponentString(blipText)
    SetBlipRoute(blipName, route)
    EndTextCommandSetBlipName(blipName)
end

function checkArray (array, val)
    for name, value in ipairs(array) do
        if value == val then
            return true
        end
    end
    return false
end

function CancelMission(loyalty) -- Fixa så man skriver CancelMission(killEarlyUppdrag1), så man slipper en massa jobbiga variablar
    if killEarlyUppdrag1 then -- Används även i uppdrag 5
        ESX.ShowNotification('Du kan inte bara döda honom hur som helst din idiot!')
        Wait(2000)
        ESX.ShowNotification('Du tror att jag har tillit till dig nu?')
        Wait(2000)
        LoseLevel(loyalty)
    elseif tookTooLong then
        ESX.ShowNotification('Är det någon jävla snigel jag hyrde eller? Kom aldrig tillbaka för jobb.')
        Wait(2000)
        LoseLevel(loyalty)
    elseif shotPedUppdrag5 then
        ESX.ShowNotification('Du kan inte bara skjuta folk hur som helst och dra till dig uppmärksamhet')
        Wait(2000)
        LoseLevel(loyalty)
    elseif killedGuardsEarly then
        ESX.ShowNotification('Följ simpla instruktioner ditt jävla mongo')
        Wait(2000)
        ESX.ShowNotification('Bra jobbat, all planering rätt i sjön')
        LoseLevel(loyalty)
    -- elseif killCloseUppdrag7 then
    --     ESX.ShowNotification('Du kan inte bara döda folk hur som helst!')
    --     Wait(2000)
    --     LoseLevelChance(1, 50)
    end
end

function LoseLevelChance(text, percentage)
    -- Percentage är alltså procent att du förlorar en level
    loseChance = math.random(0, 100)

    ESX.ShowNotification('' .. loseChance .. '')
    if loseChance < percentage then
        if text == 1 then
            ESX.ShowNotification('Man kan inte lita på sådana mongon som dig!')
            Wait(1000)
            LoseLevel(loyalty)
        end
    else
        ESX.ShowNotification('Shunon skulle bli klippt ändå, men ta det lugnt nästa gång.')
    end
end

function LoseLevel(loyalty)
    if loyalty == 'elias' then
        ESX.ShowNotification('Elias')
        ESX.TriggerServerCallback('zyke_uppdragLevelElias', function(result) level = result end)
        newLevel = level - 1
        TriggerServerEvent('zyke_uppdragUpdateLevelElias', newLevel)
    elseif loyalty == 'rodriguez' then
        ESX.ShowNotification('Rodriguez')
        ESX.TriggerServerCallback('zyke_uppdragLevelRodriguez', function(result) level = result end)
        newLevel = level - 1
        TriggerServerEvent('zyke_uppdragUpdateLevelRodriguez', newLevel)
    elseif loyalty == 'anton' then
        ESX.ShowNotification('Anton')
        ESX.TriggerServerCallback('zyke_uppdragLevelAnton', function(result) level = result end)
        newLevel = level - 1
        TriggerServerEvent('zyke_uppdragUpdateLevelAnton', newLevel)
    end
    ESX.ShowNotification('Lojalitet gick från ' .. level .. ' till ' .. newLevel .. '')
end

function ResetMissionPed()
    resetPed = true
    SetPedAsNoLongerNeeded(missionPed)
    SetPedAsNoLongerNeeded(targetPed)
    -- TriggerServerEvent('zyke_uppdragRefreshMissionPed')
    -- ESX.ShowNotification('Test - Ignorera')
    pedSpawned = false
    resetPed = false
end

RegisterNetEvent('zyke_uppdragTimer')
AddEventHandler('zyke_uppdragTimer', function()
    if timer > 0 then
        if Config.DisplayTimer2 then
            TriggerEvent('zyke_uppdragShowTimer')
            timer = timer - 1
            Wait(1000)
            TriggerEvent('zyke_uppdragTimer')
        end
    else
        if not cancelTimer then
            tookTooLong = true
            CancelMission()
            forceStop = true
        end
    end
end)

RegisterNetEvent('zyke_uppdragShowTimer')
AddEventHandler('zyke_uppdragShowTimer', function()
    while timer > 0 do
        Wait(10)
        DrawMissionText('Tid kvar: ' .. timer .. '', 0.0, 0.5)
    end
end)

-- Skit

-- RegisterCommand('levelup', function()
--     level = level + 1
--     prevLevel = level - 1
--     ESX.ShowNotification('Du levlade från nivå ' .. prevLevel .. ' till ' .. level .. '!')
-- end)

-- RegisterCommand('leveldown', function()
--     level = level - 1
--     prevLevel = level + 1
--     ESX.ShowNotification('Du levlade från nivå ' .. prevLevel .. ' till ' .. level .. '!')
-- end)

-- RegisterCommand('start1', function()
--     currentDifficulty = 1
--     jobStarted = true
--     TriggerEvent('testtest123', source)
--     TriggerEvent('zyke_uppdragMainEvent1', source)
--     justAccepted = true
--     TriggerEvent('zyke_uppdragUppdrag1Dialogue', source)
-- end)

RegisterCommand('startr1', function()
    currentDifficulty = 51
    jobStarted = true
    TriggerEvent('zyke_uppdragMainEvent1_4', source)
    justAccepted = true
    TriggerEvent('zyke_uppdragUppdrag1_4Dialogue', source)
end)

RegisterCommand('startr2', function()
    currentDifficulty = 52
    jobStarted = true
    TriggerEvent('zyke_uppdragMainEvent2_2', source)
    justAccepted = true
    TriggerEvent('zyke_uppdragUppdrag2_2Dialogue', source)
end)

RegisterCommand('simulationtest', function()
    for i = 1, 50 do
        Wait(10)
        TriggerServerEvent('zyke_uppdragItemChanceTest')
    end
end)

-- RegisterCommand('start2', function()
--     currentDifficulty = 2
--     jobStarted = true
--     TriggerEvent('zyke_uppdragMainEvent2', source)
--     justAccepted = true
--     TriggerEvent('zyke_uppdragUppdrag2Dialogue', source)
-- end)

-- RegisterCommand('start3', function()
--     currentDifficulty = 3
--     jobStarted = true
--     TriggerEvent('zyke_uppdragMainEvent3', source)
--     justAccepted = true
--     TriggerEvent('zyke_uppdragUppdrag3Dialogue', source)
-- end)

-- RegisterCommand('start4', function()
--     currentDifficulty = 4
--     jobStarted = true
--     TriggerEvent('zyke_uppdragMainEvent4', source)
--     justAccepted = true
--     TriggerEvent('zyke_uppdragUppdrag4Dialogue', source)
-- end)

-- RegisterCommand('start5', function()
--     currentDifficulty = 5
--     jobStarted = true
--     TriggerEvent('zyke_uppdragMainEvent5', source)
--     justAccepted = true
--     TriggerEvent('zyke_uppdragUppdrag5Dialogue', source)
-- end)

-- RegisterCommand('unfreeze', function()
--     FreezeEntityPosition(GetPlayerPed(-1), false)
-- end)

-- RegisterCommand('start7', function()
--     currentDifficulty = 7
--     jobStarted = true
--     TriggerEvent('zyke_uppdragMainEvent7', source)
--     justAccepted = true
--     TriggerEvent('zyke_uppdragUppdrag7Dialogue', source)
-- end)

-- RegisterCommand('specialerbjudande', function()
--     TriggerEvent('zyke_uppdragErbjudande', source)
-- end)

-- RegisterCommand('testanim', function()
--     Wait(1)
--     if not HasAnimDictLoaded("anim@heists@narcotics@trash") then
--         RequestAnimDict("anim@heists@narcotics@trash") 
--     end
--     while not HasAnimDictLoaded("anim@heists@narcotics@trash") do
--         Wait(1)
--     end
--     TaskPlayAnim(PlayerPedId(-1), 'anim@heists@narcotics@trash', 'walk', 1.0, -1.0,-1,49,0,0, 0,0)
-- end)

-- RegisterCommand('testanim', function()
--     Wait(1)
--     TaskStartScenarioInPlace(PlayerPedId(), "PROP_HUMAN_BUM_BIN", 0, true)
--     Wait(5000)
--     ClearPedTasks(GetPlayerPed(-1))
-- end)

RegisterCommand('avsluta', function()
    ESX.ShowNotification('Du har avslutit ditt uppdrag')
    forceStop = true
end)

-- RegisterCommand('forcestop', function()
--     -- if timer > Config.Timer2 / 3 then
--     --     extraBonus = true
--     -- else
--     --     extraBonus = false
--     -- end
--     RemoveBlip(blip)
--     jobDone = true
-- end)