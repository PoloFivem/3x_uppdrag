ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

function DrawMissionText(text, height, length)
    SetTextScale(0.5, 0.5)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextEdge(2, 0, 0, 0, 150)
    SetTextEntry("STRING")
    SetTextCentre(1)
    SetTextOutline()
    AddTextComponentString(text)
    DrawText(length, height)
end

function DrawText3Ds(x,y,z, text, scale)
    local onScreen,_x,_y=World3dToScreen2d(x,y,z)
    local px,py,pz=table.unpack(GetGameplayCamCoords())

    SetTextScale(scale, scale)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 255)
    SetTextEntry("STRING")
    SetTextCentre(1)
    AddTextComponentString(text)
    DrawText(_x,_y)
end

function BrowseEliasJobs(level) -- currentDifficulty 0-50
    ESX.UI.Menu.CloseAll()

    local elements = {
        {label = 'Uppdrag 1', option = 'uppdrag1'},
    }
    
    if level >= 2 then
        table.insert(elements, {label = 'Uppdrag 2', option = 'uppdrag2'})
        if level >= 3 then
            table.insert(elements, {label = 'Uppdrag 3', option = 'uppdrag3'})
            if level >= 4 then
                table.insert(elements, {label = 'Uppdrag 4', option = 'uppdrag4'})
                if level >= 5 then
                    table.insert(elements, {label = 'Uppdrag 5', option = 'uppdrag5'})
                    if level >= 6 then
                        table.insert(elements, {label = 'Kommer snart', option = 'x'})
                --         if level >= 7 then
                --             table.insert(elements, {label = 'Kommer snart', option = 'x'})
                --             if level >= 8 then
                --                 table.insert(elements, {label = 'Kommer snart', option = 'x'})
                --                 if level >= 9 then
                --                     table.insert(elements, {label = 'Kommer snart', option = 'x'})
                --                     if level >= 10 then
                --                         table.insert(elements, {label = 'Kommer snart', option = 'x'})
                --                     end
                --                 end
                --             end
                --         end
                    end
                end
            end
        end
    end

    ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'weamenu',
    {
        title = 'Hjälp Elias, lojalitet: ' .. level .. '',
        align = 'center',
        elements = elements
    },

    function(data, menu)
        -- menu.close()
        local chosen = data.current.option

        if chosen == 'uppdrag1' then
            currentDifficulty = 1
            StartJob(currentDifficulty)
        elseif chosen == 'uppdrag2' then
            currentDifficulty = 2
            StartJob(currentDifficulty)
        elseif chosen == 'uppdrag3' then
            currentDifficulty = 3
            StartJob(currentDifficulty)
        elseif chosen == 'uppdrag4' then
            ESX.TriggerServerCallback('zyke_uppdragRetrieveItem', function(hasItem)
                if hasItem then
                    currentDifficulty = 4
                    StartJob(currentDifficulty)
                else
                    ESX.ShowNotification('Köp ett dyrkset först')
                end
            end, 'lockpick')
        elseif chosen == 'uppdrag5' then
            ESX.TriggerServerCallback('zyke_uppdragRetrieveItem', function(hasItem)
                if hasItem then
                    currentDifficulty = 5
                    StartJob(currentDifficulty)
                else
                    ESX.ShowNotification('Köp ett dyrkset först')
                end
            end, 'lockpick')
        elseif chosen == 'uppdrag7' then
            currentDifficulty = 7
            StartJob(currentDifficulty)
        elseif chosen == 'x' then
            ESX.ShowNotification('Sluta snoka')
        end
    end,
    function(data, menu)
        menu.close()
    end)
end

function BrowseRodriguezJobs(level, eLevel)  -- currentDifficulty 50-100
    ESX.UI.Menu.CloseAll()

    local elements = {}
    
    if eLevel > 3 then -- Alltså över level 3
        if level >= 1 then
            table.insert(elements, {label = 'Uppdrag 1', option = 'uppdrag1'})
            if eLevel > 5 then
                if level >= 2 then
                    table.insert(elements, {label = 'Uppdrag 2', option = 'uppdrag2'})
                end
            end
        end
    else
        table.insert(elements, {label = 'Snacka med Elias först', option = 'x'})
    end


    ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'weamenu',
    {
        title = 'Hjälp Rodriguez, lojalitet: ' .. level .. '',
        align = 'center',
        elements = elements
    },

    function(data, menu)
        -- menu.close()
        local chosen = data.current.option

        if chosen == 'uppdrag1' then
            currentDifficulty = 51
            StartJob(currentDifficulty)
        elseif chosen == 'uppdrag2' then
            currentDifficulty = 52
            StartJob(currentDifficulty)
        elseif chosen == 'x' then
            ESX.ShowNotification('Sluta snoka')
        end
    end,
    function(data, menu)
        menu.close()
    end)
end

function BrowseAntonJobs(level, eLevel, rLevel)  -- currentDifficulty 100-150
    ESX.UI.Menu.CloseAll()

    local elements = {}
    
    if rLevel >= 5 then -- Minst level fyra för då har man gjort level 3 hos Elias (TVÅ EGENTLIGEN YEYE, MEN DISABLAT YEYE)
        if level >= 1 then
            table.insert(elements, {label = 'Uppdrag 1', option = 'uppdrag1'})
        end
    else
        table.insert(elements, {label = 'Snacka med Rodriguez först', option = 'x'})
    end

    ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'weamenu',
    {
        title = 'Hjälp Anton, lojalitet: ' .. level .. '',
        align = 'center',
        elements = elements
    },

    function(data, menu)
        -- menu.close()
        local chosen = data.current.option

        if chosen == 'uppdrag1' then
            currentDifficulty = 1
            StartJob(currentDifficulty)
        elseif chosen == 'x' then
            ESX.ShowNotification('Sluta snoka')
        end
    end,
    function(data, menu)
        menu.close()
    end)
end

function MainMenuPablo()
    ESX.UI.Menu.CloseAll()
    local elements = {}
    table.insert(elements, {label = 'Köp', value = 'buy'})
    table.insert(elements, {label = 'Sälj', value = 'sell'})
    ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'weamenu',
    {
        title = 'Välj ett alternativ',
        align = 'center',
        elements = elements
    },

    function(data, menu)
        local action = data.current.value

        if action == 'buy' then
            ChooseSeller(level)
        else
            ESX.TriggerServerCallback('zyke_uppdragLevelAnton', function(result) level = result end)
            TriggerEvent('zyke_uppdragLoadingText', source)
            Wait(500)
            BlackMarketSell(level)
        end
    end,
    function(data, menu)
        menu.close()
    end)
end

function ChooseSeller(level)
    ESX.UI.Menu.CloseAll()
    local elements = {}
    table.insert(elements, {label = 'Elias', value = 'elias'})
    table.insert(elements, {label = 'Rodriguez', value = 'rodriguez'})
    table.insert(elements, {label = 'Anton', value = 'anton'})
    ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'weamenu',
    {
        title = 'Välj leverantör',
        align = 'center',
        elements = elements
    },

    function(data, menu)
        local action = data.current.value

        if action == 'elias' then
            ESX.TriggerServerCallback('zyke_uppdragLevelElias', function(result) level = result end)
            TriggerEvent('zyke_uppdragLoadingText', source)
            Wait(500)
            BlackMarketElias(level)
        elseif action == 'rodriguez' then
            ESX.TriggerServerCallback('zyke_uppdragLevelRodriguez', function(result) level = result end)
            TriggerEvent('zyke_uppdragLoadingText', source)
            Wait(500)
            BlackMarketRodriguez(level)
        elseif action == 'anton' then
            ESX.TriggerServerCallback('zyke_uppdragLevelAnton', function(result) level = result end)
            TriggerEvent('zyke_uppdragLoadingText', source)
            Wait(500)
            BlackMarketAnton(level)
        end
    end,
    function(data, menu)
        MainMenuPablo()
    end)
end

function BlackMarketElias(level)
    ESX.UI.Menu.CloseAll()
    discount = (level * 0.025 - 0.025) * 100
    if discount > 25 then
        finalDiscount = 25
    else
        finalDiscount = (level * 0.025 - 0.025) * 100
    end

    local elements = {}

    -- table.insert(elements, {label = '[--- Föremål ---]', item = 'madebyzyke'})
    -- table.insert(elements, {label = 'Skottsäker Väst (Lätt): 1000 SEK', item = 'bulletproof25', amount = 1, price = 1000, buyLabel = 'Skottsäker Väst', buyLabels = 'Skottsäkra västar'}) -- Dyrk typ

    if level >= 3 then
        table.insert(elements, {label = '[--- Föremål ---]', item = 'madebyzyke'})
        table.insert(elements, {label = 'Dyrkset: 450 SEK', item = 'lockpick', amount = 1, price = 450, buyLabel = 'Skottsäker Väst', buyLabels = 'Skottsäkra västar'})
        if level >= 4 then
            table.insert(elements, {label = 'Skottsäker Väst (Lätt): 1500 SEK', item = 'bulletproof25', amount = 1, price = 1500, buyLabel = 'Skottsäker Väst', buyLabels = 'Skottsäkra västar'})
            if level >= 5 then
                table.insert(elements, {label = '[--- Ammunition ---]', item = 'madebyzyke'})
                table.insert(elements, {label = 'Pistolskott (12st): 2000 SEK', item = 'pistol_ammo', amount = 12, price = 2000, buyLabel = 'Skottsäker Väst', buyLabels = 'Skottsäkra västar'})
                table.insert(elements, {label = 'Skottsäker Väst (Medel): 4000 SEK', item = 'bulletproof50', amount = 1, price = 4000, buyLabel = 'Skottsäker Väst', buyLabels = 'Skottsäkra västar'})
            end
        end
    else
        table.insert(elements, {label = 'Tomt', item = 'madebyzyke'})
    end


    ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'weamenu',
    {
        title = 'Svarta marknaden, lojalitetsrea: ' .. finalDiscount .. '%',
        align = 'center',
        elements = elements
    },
    function(data, menu)
        local item = data.current.item
        local amount = data.current.amount
        local price = data.current.price
        
        if item ~= 'madebyzyke' then
            TriggerServerEvent('zyke_uppdragPurchase', level, item, amount, price, finalDiscount, buyLabel, buyLabels)
        end
    end,
    function(data, menu)
        ChooseSeller()
    end)
end

function BlackMarketRodriguez(level)
    ESX.UI.Menu.CloseAll()
    discount = (level * 0.025 - 0.025) * 100
    if discount > 25 then
        finalDiscount = 25
    else
        finalDiscount = (level * 0.025 - 0.025) * 100
    end

    local elements = {}

    -- table.insert(elements, {label = '[--- Föremål ---]', item = 'madebyzyke'})
    -- table.insert(elements, {label = 'Skottsäker Väst (Lätt): 1000 SEK', item = 'bulletproof25', amount = 1, price = 1000, buyLabel = 'Skottsäker Väst', buyLabels = 'Skottsäkra västar'})

    table.insert(elements, {label = 'Tomt', item = 'madebyzyke'})

    if level >= 1 then
        table.insert(elements, {label = '[--- Föremål ---]', item = 'madebyzyke'})
        table.insert(elements, {label = 'Skottsäker Väst (Lätt): 1250 SEK', item = 'bulletproof25', amount = 1, price = 1250, buyLabel = 'Skottsäker Väst', buyLabels = 'Skottsäkra västar'})
        if level >= 2 then
            table.insert(elements, {label = 'Skottsäker Väst (Medel): 3500 SEK', item = 'bulletproof50', amount = 1, price = 3500, buyLabel = 'Skottsäker Väst', buyLabels = 'Skottsäkra västar'})
            if level >= 3 then
                table.insert(elements, {label = 'Skottsäker Väst (Medel-Tung): 6000 SEK', item = 'bulletproof75', amount = 1, price = 6000, buyLabel = 'Skottsäker Väst', buyLabels = 'Skottsäkra västar'})
            end
        end
    end

    if level >= 2 then
        table.insert(elements, {label = '[--- Ammunition ---]', item = 'madebyzyke'})
        table.insert(elements, {label = 'Pistolskott (12st): 9000 SEK', item = 'pistol_ammo', amount = 12, price = 9000, buyLabel = 'Skottsäker Väst', buyLabels = 'Skottsäkra västar'})
        if level >= 3 then
            table.insert(elements, {label = 'SMG Skott (12st): 13000 SEK', item = 'smg_ammo', amount = 12, price = 13000, buyLabel = 'Skottsäker Väst', buyLabels = 'Skottsäkra västar'})
            table.insert(elements, {label = 'Shotgun Skott (6st): 17000 SEK', item = 'shotgun_ammo', amount = 6, price = 17000, buyLabel = 'Skottsäker Väst', buyLabels = 'Skottsäkra västar'})
            if level >= 4 then
                table.insert(elements, {label = 'Automatkarbin Skott (12st): 20000 SEK', item = 'rifle_ammo', amount = 12, price = 20000, buyLabel = 'Skottsäker Väst', buyLabels = 'Skottsäkra västar'})
            end
        end
    end

    ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'weamenu',
    {
        title = 'Svarta marknaden, lojalitetsrea: ' .. finalDiscount .. '%',
        align = 'center',
        elements = elements
    },
    function(data, menu)
        local item = data.current.item
        local amount = data.current.amount
        local price = data.current.price
        
        if item ~= 'madebyzyke' then
            TriggerServerEvent('zyke_uppdragPurchase', level, item, amount, price, finalDiscount, buyLabel, buyLabels)
        end
    end,
    function(data, menu)
        ChooseSeller()
    end)
end

function BlackMarketAnton(level)
    ESX.UI.Menu.CloseAll()
    discount = (level * 0.025 - 0.025) * 100
    if discount > 25 then
        finalDiscount = 25
    else
        finalDiscount = (level * 0.025 - 0.025) * 100
    end

    local elements = {}

    if level < 1 then
        table.insert(elements, {label = 'Tomt', item = 'madebyzyke'})
    end

    if level >= 2 then
        table.insert(elements, {label = '[--- Föremål ---]', item = 'madebyzyke'})
        table.insert(elements, {label = 'Skottsäker Väst (Medel-Tung): 4500 SEK', item = 'bulletproof75', amount = 1, price = 4500, buyLabel = 'Skottsäker Väst', buyLabels = 'Skottsäkra västar'})
        if level >= 3 then
            table.insert(elements, {label = 'Skottsäker Väst (Tung): 8000 SEK', item = 'bulletproof100', amount = 1, price = 8000, buyLabel = 'Skottsäker Väst', buyLabels = 'Skottsäkra västar'})
            table.insert(elements, {label = 'Ljuddämpare: 7500 SEK', item = 'suppressor', amount = 1, price = 7500, buyLabel = 'Skottsäker Väst', buyLabels = 'Skottsäkra västar'})
        end
    else
        table.insert(elements, {label = 'Tomt', item = 'madebyzyke'})
    end

    if level >= 3 then
        table.insert(elements, {label = '[--- Nycklar ---]', item = 'madebyzyke'})
        table.insert(elements, {label = 'Grönt Kort: 25000 SEK', item = 'greencard', amount = 1, price = 25000, buyLabel = 'Skottsäker Väst', buyLabels = 'Skottsäkra västar'})
        if level >= 4 then
            table.insert(elements, {label = 'Blått Kort: 50000 SEK', item = 'bluecard', amount = 1, price = 50000, buyLabel = 'Skottsäker Väst', buyLabels = 'Skottsäkra västar'})
            if level >= 5 then
                table.insert(elements, {label = 'Rött Kort: 75000 SEK', item = 'redcard', amount = 1, price = 75000, buyLabel = 'Skottsäker Väst', buyLabels = 'Skottsäkra västar'})
            end
        end
    end

    if Config.SellWeapons then
        if level >= 3 then
            table.insert(elements, {label = '[--- Vapen ---]', item = 'madebyzyke'})
            table.insert(elements, {label = 'SNS Pistol: 90000 SEK', item = 'snspistol', amount = 1, price = 90000, buyLabel = 'Skottsäker Väst', buyLabels = 'Skottsäkra västar'})
            if level >= 4 then
                table.insert(elements, {label = 'Pistol .50: 140000 SEK', item = 'pistol50', amount = 1, price = 140000, buyLabel = 'Skottsäker Väst', buyLabels = 'Skottsäkra västar'})
                if level >= 5 then
                    table.insert(elements, {label = 'Micro SMG: 155000 SEK', item = 'microsmg', amount = 1, price = 155000, buyLabel = 'Skottsäker Väst', buyLabels = 'Skottsäkra västar'})
                end
            end
        end
    end

    ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'weamenu',
    {
        title = 'Svarta marknaden, lojalitetsrea: ' .. finalDiscount .. '%',
        align = 'center',
        elements = elements
    },
    function(data, menu)
        local item = data.current.item
        local amount = data.current.amount
        local price = data.current.price
        
        if item ~= 'madebyzyke' then
            TriggerServerEvent('zyke_uppdragPurchase', level, item, amount, price, finalDiscount, buyLabel, buyLabels)
        end
    end,
    function(data, menu)
        ChooseSeller()
    end)
end

-- Antons lojalitet
function BlackMarketSell(level)
    ESX.UI.Menu.CloseAll()
    bonus = (level * 0.025 - 0.025) * 100
    if bonus > 25 then
        finalBonus = 25
    else
        finalBonus = (level * 0.025 - 0.025) * 100
    end
    ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'weamenu',
    {
        title = 'Sälj, lojalitetsbonus: ' .. finalBonus .. '%',
        align = 'center',
        elements = {
            {label = 'Guldig Chained Medusa Ring: 2200 kr', item = 'ring1', price = 2200, sellLabel = 'Guldig Chained Medusa Ring', labels = 'Chained Medusa Ringar'},
            {label = 'Silvrig Medusa Chain Ring: 3500 kr', item = 'ring2', price = 3500, sellLabel = 'Silvrig Medusa Chain Ring', labels = 'Medusa Chain Ringar'}
        }
    },

    function(data, menu)
        local item = data.current.item
        local price = data.current.price
        local name = data.current.sellLabel
        local names = data.current.labels

        TriggerServerEvent('zyke_uppdragSellItems', level, item, price, name, names)
    end,
    function(data, menu)
        MainMenuPablo()
    end)
end